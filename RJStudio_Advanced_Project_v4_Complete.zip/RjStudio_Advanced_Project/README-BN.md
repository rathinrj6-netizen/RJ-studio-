# RJ Studio — Advanced Android Starter (v4)

এই প্রজেক্টটি RJ Studio-এর নতুন Android starter version। এতে বাংলা হোম স্ক্রিন, লেখার/কোড সহায়তার ইনপুট পেজ, ChatGPT খোলার শর্টকাট এবং GitHub Actions-এ APK build workflow আছে।

## APK তৈরি করার নিয়ম (ফ্রি)

1. এই ZIP Extract করুন।
2. `RjStudio_Advanced_Project` ফোল্ডারের **ভেতরের সব ফাইল ও ফোল্ডার** GitHub repository-এর root-এ আপলোড করুন—বিশেষ করে `.github/workflows/build-apk.yml`।
3. GitHub-এ repository খুলে **Actions** ট্যাব নির্বাচন করুন।
4. `Build RJ Studio APK` workflow খুলে **Run workflow** চাপুন। `main` বা `master` branch-এ push করলেও workflow চালু হবে।
5. বিল্ড সফল হলে run-এর নিচে **Artifacts → RjStudio-debug-apk** থেকে ZIP ডাউনলোড করুন।
6. Artifact ZIP Extract করে `app-debug.apk` Android ফোনে ইনস্টল করুন। ফোনে ইনস্টল করার আগে Android-এর সতর্কতা পড়ুন।

## এই সংস্করণে যা আছে

- Android Gradle Plugin 8.7.3 ও Gradle 8.9 নির্দিষ্ট করা।
- Java 17 ও Android SDK Platform 35 দিয়ে GitHub Actions build।
- Build ব্যর্থ হলে stack trace লগ।
- APK ফাইল আছে কি না যাচাই করে তারপর artifact upload।
- বাংলা UI, লেখার/কোডের prompt input এবং ChatGPT খোলার shortcut।
- কোনো paid AI API key বাধ্যতামূলক নয়।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- এই ZIP **নিজে থেকে তৈরি APK নয়**। GitHub Actions-এ build সফল হওয়ার পর APK artifact তৈরি হবে।
- এই পরিবেশে Android SDK/Gradle দিয়ে APK compile বা ফোনে install-test করা হয়নি।
- লেখার/কোডের ইনপুট এই starter app-এর ভেতর থেকে সরাসরি AI সার্ভারে পাঠানো হয় না; এটি ChatGPT খোলার shortcut দেয়। পূর্ণ AI integration পরে নিরাপদ backend বা উপযুক্ত API দিয়ে আলাদাভাবে তৈরি করতে হবে।
- এই starter version-এ আপনার পুরোনো প্রজেক্টের সব ফিচার/ছবি স্বয়ংক্রিয়ভাবে অন্তর্ভুক্ত হয়েছে—এমন দাবি করা হচ্ছে না।
