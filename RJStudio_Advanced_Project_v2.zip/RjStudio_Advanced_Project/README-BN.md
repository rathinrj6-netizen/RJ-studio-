# RJ Studio Advanced Android Project

এটি RJ Studio-এর একটি নতুন, পরিষ্কার Android প্রজেক্ট। UI-তে বাংলা হোম স্ক্রিন, টুল কার্ড, লেখার/কোডের জন্য ইনপুট, ChatGPT লিংক এবং APK বিল্ড গাইড রয়েছে।

## APK তৈরি
1. পুরো ZIP extract করে সব ফাইল GitHub repository-র root-এ upload/commit করুন।
2. `.github/workflows/build-apk.yml` ফাইলটিও রাখতে হবে।
3. GitHub > Actions > Build Rj Studio APK > Run workflow।
4. সফল হলে `RjStudio-debug-apk` Artifact download করুন; ZIP extract করে `app-debug.apk` install করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই প্রজেক্টটি নতুন UI starter, পূর্ণ AI engine নয়।
- ইনপুট লেখা সরাসরি AI-তে পাঠানো হয় না; ChatGPT খুলে ব্যবহারকারীকে লেখা কপি করে পাঠাতে হবে।
- APK এখনো এই পরিবেশে compile/install-test করা হয়নি। GitHub Actions-এ build result যাচাই করতে হবে।
- কোনো paid API বা paid service যুক্ত করা হয়নি।
