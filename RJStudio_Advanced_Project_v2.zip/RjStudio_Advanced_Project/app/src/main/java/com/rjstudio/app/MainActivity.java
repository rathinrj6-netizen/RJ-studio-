package com.rjstudio.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private LinearLayout root, content;
    private int purple = Color.rgb(124,58,237);
    private int ink = Color.rgb(15,23,42);
    private int muted = Color.rgb(100,116,139);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11,16,32));
        getWindow().setNavigationBarColor(Color.rgb(11,16,32));
        buildHome();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void pad(View v, int all) { v.setPadding(all,all,all,all); }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackground(bg(purple, 24));
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private void buildHome() {
        root = column(); root.setBackgroundColor(Color.rgb(248,250,252));
        LinearLayout header = column(); header.setPadding(22,22,22,24); header.setBackground(bg(Color.rgb(11,16,32),0));
        TextView brand = text("✦ RJ STUDIO", 24, Color.WHITE, true);
        TextView tagline = text("Your creative AI workspace", 14, Color.rgb(203,213,225), false);
        header.addView(brand); header.addView(tagline);
        root.addView(header);
        ScrollView scroll = new ScrollView(this);
        content = column(); content.setPadding(18,18,18,24);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        TextView welcome = text("স্বাগতম 👋", 25, ink, true); content.addView(welcome);
        TextView desc = text("এক জায়গায় তোমার কাজ, আইডিয়া ও দ্রুত টুলস।", 15, muted, false);
        content.addView(desc);
        LinearLayout hero = column(); hero.setPadding(18,18,18,18); hero.setBackground(bg(Color.rgb(237,233,254),22));
        TextView h = text("Create something great", 21, Color.rgb(76,29,149), true);
        TextView p = text("RJ Studio-এর উন্নত সংস্করণ — সহজ, দ্রুত ও পরিষ্কার ইন্টারফেস।", 14, Color.rgb(91,33,182), false);
        hero.addView(h); hero.addView(p); hero.addView(button("কাজ শুরু করো", () -> showTools()));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,-2); hp.topMargin=18; content.addView(hero,hp);
        TextView section = text("তোমার টুলস", 20, ink, true); section.setPadding(0,22,0,8); content.addView(section);
        addCard("✍️  লেখার সহায়তা", "মেসেজ, পোস্ট বা আইডিয়া লিখে সাজাও", () -> showPrompt("লেখার সহায়তা"));
        addCard("💻  কোড সহায়তা", "কোড, বাগ বা Error-এর বিবরণ প্রস্তুত করো", () -> showPrompt("কোড সহায়তা"));
        addCard("📦  APK বিল্ড গাইড", "GitHub Actions দিয়ে APK বানানোর ধাপ দেখো", () -> showBuildGuide());
        addCard("🌐  ChatGPT খুলুন", "প্রশ্ন, ছবি ও ফাইল দিয়ে সাহায্য নাও", () -> openUrl("https://chatgpt.com/"));
        TextView note = text("নোট: AI উত্তর পেতে ইন্টারনেট ও আলাদা AI সার্ভিস/অ্যাকাউন্ট লাগতে পারে। এই প্রজেক্টে পেইড API স্বয়ংক্রিয়ভাবে যুক্ত করা নেই।", 12, muted, false);
        note.setPadding(4,18,4,8); content.addView(note);
    }
    private void addCard(String title, String subtitle, Runnable action) {
        LinearLayout card = column(); card.setPadding(16,12,16,14); card.setBackground(bg(Color.WHITE,18));
        TextView t = text(title,17,ink,true); TextView s = text(subtitle,13,muted,false);
        card.addView(t); card.addView(s);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.topMargin=10;
        content.addView(card,lp); card.setElevation(2); card.setOnClickListener(v -> action.run());
    }
    private void showTools() {
        content.removeAllViews();
        TextView title = text("কাজ বেছে নাও",24,ink,true); content.addView(title);
        addCard("✍️ লেখার সহায়তা","লেখার জন্য একটি নির্দেশনা তৈরি করো",()->showPrompt("লেখার সহায়তা"));
        addCard("💻 কোড সহায়তা","কোড/ত্রুটির বিবরণ প্রস্তুত করো",()->showPrompt("কোড সহায়তা"));
        addCard("📦 APK বিল্ড গাইড","বিল্ডের ধাপ দেখো",()->showBuildGuide());
        content.addView(button("হোমে ফিরুন",()->buildHome()));
    }
    private void showPrompt(String kind) {
        content.removeAllViews();
        content.addView(text(kind,23,ink,true));
        TextView hint=text("তোমার কাজ বা সমস্যাটি লিখো:",14,muted,false); hint.setPadding(0,10,0,8); content.addView(hint);
        EditText input = new EditText(this); input.setMinLines(5); input.setGravity(Gravity.TOP);
        input.setHint("এখানে লিখুন…"); input.setBackground(bg(Color.WHITE,16)); pad(input,14); content.addView(input);
        content.addView(button("ChatGPT-তে সাহায্য নাও",()->{
            String msg=input.getText().toString().trim();
            if(msg.isEmpty()){Toast.makeText(this,"আগে কিছু লিখুন",Toast.LENGTH_SHORT).show();return;}
            openUrl("https://chatgpt.com/");
            Toast.makeText(this,"লেখাটি কপি করে ChatGPT-তে পাঠান",Toast.LENGTH_LONG).show();
        }));
        content.addView(button("ফিরে যাও",()->showTools()));
    }
    private void showBuildGuide() {
        content.removeAllViews();
        content.addView(text("APK তৈরি করার গাইড",23,ink,true));
        String[] steps = {
            "১. এই ZIP ফাইলটি GitHub repository-তে আপলোড করুন।",
            "২. .github/workflows ফোল্ডারটিও আপলোড হয়েছে নিশ্চিত করুন।",
            "৩. Actions ট্যাব খুলুন এবং Build Rj Studio APK workflow চালান।",
            "৪. Build সফল হলে Artifacts থেকে RjStudio-debug-apk ডাউনলোড করুন।",
            "৫. ZIP Extract করে app-debug.apk ইনস্টল করুন।"
        };
        for(String s:steps){ TextView t=text(s,15,ink,false); t.setPadding(0,12,0,12); content.addView(t); }
        content.addView(button("GitHub খুলুন",()->openUrl("https://github.com/rathinrj6-netizen/RJ")));
        content.addView(button("ফিরে যাও",()->buildHome()));
    }
    private void openUrl(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch(Exception e){Toast.makeText(this,"লিংক খোলা যায়নি",Toast.LENGTH_SHORT).show();}
    }
}
