# RJ Studio — Java, Android, AI সার্ভার ও Coding Agent-এর পূর্ণ হ্যান্ডঅফ

## এই প্যাকেজে থাকা অংশ
- Android Java app: `app/src/main/java/com/rjstudio/app/`
- Android manifest/resources/assets: `app/src/main/`
- Gradle build config: `build.gradle`, `settings.gradle`, `app/build.gradle`
- AI gateway: `server/server.js`
- bounded coding worker: `server/agent-worker.js`
- task queue: `server/agent-tasks.json`
- local smoke tests: `server/smoke-test.js`
- Docker image/Compose: `server/Dockerfile`, `server/docker-compose.yml`
- CI APK build: `.github/workflows/build-apk.yml`
- Bengali setup/security docs: `server/README-BN.md`, `server/SECURITY_AND_DEPLOYMENT_BN.md`

## লোকাল সার্ভার পরীক্ষা
Node.js 20+ দিয়ে `cd server`, তারপর `npm run check` এবং `npm test` চালান। AI ছাড়া smoke test চলার কথা। বাস্তব AI চালাতে provider URL/model/key এবং gateway token environment-এ সেট করতে হবে।

## Coding Worker চালানো
প্রজেক্ট root থেকে `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL` সেট করে `node server/agent-worker.js` চালান। কাজের তালিকা `server/agent-tasks.json`-এ। ডিফল্টে এক রান-এ সর্বোচ্চ ৩টি pending task প্রক্রিয়া হয়। এটি সারাদিন চালু থাকে না; scheduler/always-on host/CI runner আলাদা করে সেট করতে হবে।

## APK build
GitHub Actions-এর `Build Rj Studio APK` workflow চালান এবং artifact ডাউনলোড করুন। Build pass না হওয়া পর্যন্ত APK সফল বলে গণ্য করবেন না।

## যা এই ZIP নিজে থেকে করতে পারে না
- কোনো cloud account তৈরি বা server deploy করতে পারে না।
- AI provider-এর paid/free quota বা uptime নিশ্চিত করতে পারে না।
- GitHub Actions চালু করতে repository access লাগে।
- APK install করে বাস্তব ফোনে পরীক্ষা করতে পারে না।
- Coding Worker arbitrary shell command চালায় না; তার test allowlist সীমিত।
- AI response সবসময় সঠিক হবে—এ নিশ্চয়তা নেই; পরিবর্তন review ও backup দরকার।

## চূড়ান্ত যাচাই তালিকা
- [ ] `npm run check` pass
- [ ] `npm test` pass
- [ ] server production token configured
- [ ] HTTPS deployment complete
- [ ] real AI provider test pass
- [ ] GitHub Actions APK build pass
- [ ] APK installs on target Android phone
- [ ] background service/notification tested on device
- [ ] AI coding changes reviewed and rollback tested
