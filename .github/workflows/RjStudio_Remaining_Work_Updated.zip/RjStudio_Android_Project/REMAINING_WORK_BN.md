## নতুন প্রোটোটাইপ সংযোজন — Background Assistant
- Android foreground service ও চলমান notification-এর প্রাথমিক কাঠামো যোগ করা হয়েছে।
- অ্যাপের মধ্যে “ব্যাকগ্রাউন্ড চালু/বন্ধ” বোতাম যোগ করা হয়েছে।
- এটি কেবল সার্ভিস/স্ট্যাটাস প্রোটোটাইপ; বাস্তব AI backend, queue-তে AI task চালানো, task persistence/retry, reboot handling, এবং Android 13–15 ডিভাইসে পরীক্ষা এখনো বাকি।
- APK build ও বাস্তব ডিভাইস পরীক্ষা সফল হয়েছে বলে ধরে নেওয়া যাবে না যতক্ষণ GitHub Actions build এবং ইনস্টল/রান পরীক্ষা করা না হয়।

# Rj Studio — অবশিষ্ট কাজ ও গ্রহণযোগ্যতার মানদণ্ড

এই ফাইলটি বাস্তব অবস্থা স্পষ্ট রাখার জন্য। কোনো ফিচার UI-তে দেখা গেলেই সেটি কার্যকর বলে গণ্য হবে না।

## P0 — APK build ও নিরাপদ বেস
- [ ] GitHub Actions-এ build সফল
- [ ] APK artifact ডাউনলোড, SHA-256 checksum এবং ইনস্টল পরীক্ষা
- [ ] Android 6+ এবং লক্ষ্য Android সংস্করণে smoke test
- [ ] file chooser, app lifecycle, offline/error state পরীক্ষা

## P1 — AI Assistant
- [ ] নিরাপদ server-side backend; API key APK/HTML-এ রাখা যাবে না
- [ ] স্পষ্ট AI connection status, timeout, retry এবং rate-limit handling
- [ ] AI-র কোড পরিবর্তনের আগে diff/preview এবং ব্যবহারকারীর অনুমোদন
- [ ] build log থেকে ত্রুটি শনাক্ত; সীমিত patch; build/test পুনরায় চালানো
- [ ] কোনো বিল্ড ব্যর্থ হলে সেটিকে সফল দেখাবে না

## P1 — ফোনের অনুমোদিত নিয়ন্ত্রণ
- [ ] প্রতিটি অনুমতির আগে ব্যাখ্যা ও opt-in
- [ ] প্রয়োজন হলে আলাদা native service; সহজ disable/stop ব্যবস্থা
- [ ] শুধু Android API-তে অনুমোদিত কাজ; lock/security bypass নয়
- [ ] বাংলা voice input/output-এর native fallback ও permission flow

## P2 — Update ও প্রকাশ
- [ ] versionCode/versionName ব্যবস্থাপনা
- [ ] signed release key নিরাপদ secret store-এ
- [ ] update manifest, integrity verification, rollback পরিকল্পনা
- [ ] crash/diagnostic রিপোর্টে ব্যক্তিগত তথ্য বাদ দেওয়া

## P2 — ফ্রি পরিষেবা ও গোপনীয়তা
- [ ] প্রতিটি ব্যবহৃত পরিষেবার free-tier/limit নথিভুক্ত
- [ ] খরচ হতে পারে এমন API/service ডিফল্টে সক্রিয় নয়
- [ ] লগ/ফাইল/মাইক্রোফোন/লোকেশনের ডেটা সংগ্রহে ন্যূনতমতা ও সম্মতি

## সফলতার সংজ্ঞা
প্রতিটি চেকলিস্টের আইটেমের জন্য পরীক্ষার ফলাফল/লগ থাকতে হবে। “কোনো সমস্যা নেই” নিশ্চিত করা যায় না; শনাক্ত সমস্যা, সীমাবদ্ধতা এবং পরীক্ষার কভারেজ প্রকাশ করতে হবে।


## Coding Agent-এর স্থায়ী কাজের নিয়ম
- `AGENT_MINDSET_BN.md`-এ inspect → plan → patch → test → review → report workflow এবং নিরাপত্তার সীমা নথিভুক্ত।
- `AGENT_TASK_QUEUE_TEMPLATE.json` প্রাথমিক backlog ও acceptance criteria দেয়।
- **এগুলো নির্দেশনা/টেমপ্লেট; AI backend বা sandbox runner চালু করে না।** সেই integration না হওয়া পর্যন্ত স্বয়ংক্রিয় কোডিং বাস্তবে সক্রিয় নয়।


## নতুন সার্ভার সংযোগের অবস্থা
- [x] Node.js AI Gateway scaffold যোগ করা হয়েছে।
- [x] `/health`, `/api/chat`, `/api/agent/plan` endpoint যোগ করা হয়েছে।
- [x] API key Android app-এ না রেখে server environment-এ রাখার নকশা।
- [x] UI-তে HTTPS backend URL এবং health-check control যোগ করা হয়েছে।
- [x] GitHub Actions-এ Node.js syntax/JSON validation যোগ করা হয়েছে।
- [ ] Hosting-এ deploy করা — ব্যবহারকারীর hosting/account access দরকার।
- [ ] Valid AI provider URL, API key ও model configure করা — secret নিজে থেকে তৈরি করা যায় না।
- [ ] End-to-end AI response পরীক্ষা — deploy/configuration-এর পরে।
- [ ] Sandboxed code editing, test runner এবং approval-gated patch application।
- [ ] Android APK build এবং physical-device test।
