# RJ Studio — বাকি কাজের আলাদা অবস্থা (২৪ অক্টোবর ২০২৬)

এই নথিতে প্রতিটি বাকি কাজ আলাদা করে বলা হয়েছে। সোর্স কোডে পরিবর্তন করা আর অনলাইন সার্ভার চালু করা/ফোনে APK পরীক্ষা করা এক জিনিস নয়। কোনো পরীক্ষা চালানো না হলে সেটিকে PASS বলা হয়নি।

## 1. AI Gateway ও CORS — সোর্সে সংশোধিত, লোকাল টেস্ট PASS
- এখন `CORS_ORIGIN`-এর সঙ্গে request-এর `Origin` হুবহু মিলে গেলেই CORS response header দেওয়া হয়।
- `Origin: null` পরীক্ষার জন্য `CORS_ORIGIN=null` সেট করা যায়; এটি কেবল তখনই ব্যবহার করুন যখন bundled `file://` WebView সত্যিই `Origin: null` পাঠায়। এই সেটিং অন্য null-origin কনটেন্টকেও অনুমতি দিতে পারে, তাই production-এ gateway token ও HTTPS আবশ্যক।
- Smoke test-এ অনুমোদিত origin, অননুমোদিত origin এবং preflight পরীক্ষা যোগ করা হয়েছে।
- ফলাফল: `node --check` এবং `node smoke-test.js` PASS।

## 2. Android অ্যাপ থেকে AI-তে সংযোগ — সোর্সে URL/token flow আছে, বাস্তব ডিভাইস পরীক্ষা BLOCKED
- Settings-এ HTTPS Gateway URL ও gateway token দেওয়ার ব্যবস্থা আছে।
- টোকেন session storage-এ থাকে; অ্যাপের session শেষ হলে আবার দিতে হতে পারে। Provider API key কখনো Android app-এ দেবেন না।
- বাস্তব সংযোগের জন্য HTTPS-hosted gateway, server-side `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, `RJ_GATEWAY_TOKEN` এবং উপযুক্ত `CORS_ORIGIN` দরকার।
- এই workspace-এ provider credentials বা deployed endpoint নেই, তাই live AI request পরীক্ষা করা যায়নি।

## 3. সার্ভার অনলাইনে প্রকাশ — BLOCKED
- Dockerfile ও Docker Compose কনফিগারেশন আছে।
- বাস্তব hosting account, domain/HTTPS এবং secret values এখানে উপলভ্য নয়; তাই deploy করা হয়নি।
- চালু করার আগে hosting-এর secret/environment settings-এ `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, `RJ_GATEWAY_TOKEN`, `CORS_ORIGIN` সেট করুন।

## 4. APK build — BLOCKED
- GitHub Actions workflow-তে Android SDK, Java 17, Gradle 8.9 দিয়ে debug APK build ও artifact upload-এর ধাপ আছে।
- বর্তমান runtime-এ `gradle` ও `sdkmanager` নেই, তাই এখানে APK compile করা যায়নি।
- GitHub repository-তে project push করে Actions → `Build Rj Studio APK` → `Run workflow` চালাতে হবে; সফল হলে `RjStudio-debug-apk` artifact থেকে `app-debug.apk` নিন। Workflow সফল না হওয়া পর্যন্ত APK তৈরি হয়েছে বলা যাবে না।

## 5. বাস্তব ফোন পরীক্ষা — BLOCKED
- এই সেশনে সংযুক্ত Android device নেই। Install, voice recognition, notification/background behavior ও network call পরীক্ষা করা হয়নি।
- APK তৈরি হলে ফোনে install করে আলাদাভাবে পরীক্ষা করুন; permission prompts এবং Android battery restrictions লক্ষ্য করুন।

## 6. সর্বক্ষণ স্বয়ংক্রিয় কোডিং/ফোন নিয়ন্ত্রণ — এখনো সম্পূর্ণ নয়
- Background service শুধু notification/status ও task list সামলায়; নিজে থেকে AI coding করে না।
- Worker সীমিত prototype; production autonomous coding-এর আগে isolated workspace, review/approval, logs, rollback ও server-side scheduling দরকার।
- Android app-এর task queue এবং server worker-এর মধ্যে live task execution integration এই প্যাকেজে সম্পূর্ণ বলে দাবি করা হচ্ছে না।

## 7. আয়/বিজ্ঞাপন — সেটিংস আছে, বাস্তব আয় BLOCKED
- Monetization settings UI কেবল পছন্দ/অবস্থা সংরক্ষণ করে। এটি নিজে বিজ্ঞাপন দেখায় বা পেমেন্ট তৈরি করে না।
- বাস্তব monetization-এর জন্য উপযুক্ত publisher account, app ID/ad SDK integration, policy review এবং payout setup দরকার। কোনো আয়ের নিশ্চয়তা নেই।

## এই প্যাকেজে চালানো যাচাই
- Node syntax checks: PASS
- Server smoke tests, including CORS and token authorization: PASS
- Inline HTML JavaScript syntax: PASS
- XML/JSON parse: PASS
- ZIP integrity: PASS
- Android Gradle build / APK / device test: NOT RUN (tools/device unavailable)
