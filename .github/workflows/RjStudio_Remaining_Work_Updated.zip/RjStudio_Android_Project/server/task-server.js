'use strict';
// Separate authenticated task-management API. It does not execute code or shell commands.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const PORT = Number(process.env.TASK_PORT || 8788);
const TOKEN = process.env.RJ_TASKS_TOKEN || '';
const ORIGIN = (process.env.TASKS_CORS_ORIGIN || '').trim();
const FILE = process.env.RJ_TASKS_FILE || path.join(__dirname, 'tasks-store.json');
if (process.env.NODE_ENV === 'production' && !TOKEN) {
  console.error('Refusing production start: RJ_TASKS_TOKEN must be configured.'); process.exit(1);
}
function load() { try { const x = JSON.parse(fs.readFileSync(FILE, 'utf8')); return Array.isArray(x) ? x : []; } catch (e) { if (e.code !== 'ENOENT') console.error('Task store unreadable:', e.message); return []; } }
let tasks = load();
function save() { const tmp = `${FILE}.tmp`; fs.writeFileSync(tmp, JSON.stringify(tasks, null, 2), { mode: 0o600 }); fs.renameSync(tmp, FILE); }
function send(req, res, status, data) {
  const headers = {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Vary':'Origin','Access-Control-Allow-Methods':'GET,POST,PATCH,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Authorization'};
  if (ORIGIN && req.headers.origin === ORIGIN) headers['Access-Control-Allow-Origin'] = ORIGIN;
  res.writeHead(status, headers); res.end(status === 204 ? undefined : JSON.stringify(data));
}
function auth(req) { if (!TOKEN) return process.env.NODE_ENV !== 'production'; const h=req.headers.authorization||''; const s=Buffer.from(h.startsWith('Bearer ')?h.slice(7):''); const t=Buffer.from(TOKEN); return s.length===t.length && crypto.timingSafeEqual(s,t); }
function body(req) { return new Promise((resolve,reject)=>{let raw=''; req.on('data',c=>{raw+=c;if(Buffer.byteLength(raw)>16384){reject(Object.assign(new Error('Body too large'),{status:413}));req.destroy();}}); req.on('end',()=>{try{resolve(raw?JSON.parse(raw):{});}catch{reject(Object.assign(new Error('Invalid JSON'),{status:400}));}});req.on('error',reject);}); }
const server=http.createServer(async(req,res)=>{
 if(req.method==='OPTIONS') return send(req,res,204,{});
 const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);
 if(req.method==='GET'&&u.pathname==='/health') return send(req,res,200,{ok:true,service:'rj-studio-task-server',taskCount:tasks.length,timestamp:new Date().toISOString()});
 if(!u.pathname.startsWith('/api/tasks')) return send(req,res,404,{error:'Not found'});
 if(!auth(req)) return send(req,res,401,{error:'Unauthorized'});
 if(req.method==='GET'&&u.pathname==='/api/tasks') return send(req,res,200,{ok:true,tasks});
 if(req.method==='POST'&&u.pathname==='/api/tasks') {
  try { const b=await body(req); const title=typeof b.title==='string'?b.title.trim():''; const description=typeof b.description==='string'?b.description.trim():'';
   if(!title) return send(req,res,400,{error:'title is required'}); if(title.length>200||description.length>4000) return send(req,res,413,{error:'title or description too long'});
   const task={id:crypto.randomUUID(),title,description,status:'pending',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}; tasks.push(task); save(); return send(req,res,201,{ok:true,task});
  } catch(e){return send(req,res,e.status||500,{error:e.status?e.message:'Could not save task'});}
 }
 const m=u.pathname.match(/^\/api\/tasks\/([a-f0-9-]+)$/i);
 if(req.method==='PATCH'&&m){
  try {const b=await body(req); const task=tasks.find(t=>t.id===m[1]); if(!task)return send(req,res,404,{error:'Task not found'}); if(!['pending','in_progress','done','blocked'].includes(b.status))return send(req,res,400,{error:'status must be pending, in_progress, done, or blocked'}); task.status=b.status; task.updatedAt=new Date().toISOString(); save(); return send(req,res,200,{ok:true,task});}
  catch(e){return send(req,res,e.status||500,{error:e.status?e.message:'Could not update task'});}
 }
 return send(req,res,404,{error:'Not found'});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`RJ Studio task server listening on ${PORT}; auth enabled: ${Boolean(TOKEN)}`));
