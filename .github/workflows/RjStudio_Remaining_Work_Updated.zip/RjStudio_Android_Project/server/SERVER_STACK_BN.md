# RJ Studio — সার্ভার স্ট্যাক (বাংলা)

এই ফোল্ডারে বর্তমানে অন্তর্ভুক্ত সার্ভার-সাইড অংশগুলো:

1. **AI Gateway (`server.js`)** — `/health`, `/api/chat`, `/api/agent/plan`; OpenAI-compatible API ব্যবহার করে।
2. **Bounded Coding Worker (`agent-worker.js`)** — কিউ থেকে সীমিত সংখ্যক কাজ নেয়, অনুমোদিত ফাইল-টাইপেই পরিবর্তন করে এবং কেবল allowlisted টেস্ট চালায়।
3. **Task Queue & Reports (`agent-tasks.json`)** — pending/running/completed/failed/blocked স্ট্যাটাস ও রিপোর্ট রাখে।
4. **Gateway container (`Dockerfile`)** — API সার্ভার চালানোর ইমেজ।
5. **Worker container (`Dockerfile.worker`)** — আলাদা, স্পষ্টভাবে চালু করতে হয় এমন worker ইমেজ।
6. **Compose orchestration (`docker-compose.yml`)** — gateway সার্ভিস ও ঐচ্ছিক worker profile।
7. **Configuration template (`.env.example`)**, smoke tests এবং নিরাপত্তা/ডিপ্লয়মেন্ট গাইড।

## চালানোর আগে

- Node.js 20+ দরকার। Docker ব্যবহার করলে Docker Compose v2 দরকার।
- `.env.example` কপি করে `.env` তৈরি করুন; `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, এবং দীর্ঘ/অনুমান-অযোগ্য `RJ_GATEWAY_TOKEN` নিজে নিরাপদ পরিবেশে সেট করতে হবে। আসল secret কখনো ZIP, Git, APK বা চ্যাটে রাখবেন না।
- AI provider-এর endpoint ও API key ছাড়া AI সার্ভার কাজ করবে না; বিনামূল্যের ব্যবহার/হোস্টিং নিশ্চিত নয়।

## লোকাল পরীক্ষা

```sh
cd server
npm run check
npm test
```

## Docker চালানো

`server` ফোল্ডার থেকে, `.env` ফাইল প্রস্তুত থাকার পর:

```sh
docker compose up --build -d
```

শুধু অনুমোদিত queue কাজ প্রসেস করতে worker একবার চালান:

```sh
docker compose --profile worker run --rm rj-studio-worker
```

Worker ডিফল্টভাবে সবসময় চলতে থাকে না; এটি queue-তে pending কাজ থাকলে সীমিত সংখ্যক কাজ চালিয়ে থামে। প্রকল্প ফোল্ডার worker-এ write-mount করা হয়, তাই চালানোর আগে backup/version control রাখুন এবং পরিবর্তন review করুন।

## যা এখনও সংযুক্ত/সম্পন্ন নয়

- Android অ্যাপের `MainActivity` থেকে gateway-তে authenticated API call সংযোগ।
- বাস্তব speech-to-text server; বর্তমান voice feature ডিভাইস/অ্যাপের অনুমতির ওপর নির্ভরশীল।
- পেমেন্ট, বিজ্ঞাপন, আয়ের হিসাব বা dollar payout সার্ভার। এগুলো যোগ করতে নির্দিষ্ট বৈধ provider, অ্যাকাউন্ট, নীতি-অনুমোদন ও credentials লাগে; স্বয়ংক্রিয় আয় নিশ্চিত করা যায় না।
- Cloud deployment/domain/TLS, provider credentials, production load/security testing।
- APK build এবং বাস্তব Android ফোনে পরীক্ষা।

অতএব, এই প্যাকেজে সার্ভার কোড ও কনফিগারেশন আছে; এর অর্থ এই নয় যে সার্ভার ইতিমধ্যে ইন্টারনেটে deploy হয়েছে বা AI key সেট করা আছে।
