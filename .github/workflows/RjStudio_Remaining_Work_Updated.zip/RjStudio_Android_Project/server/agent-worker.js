#!/usr/bin/env node
'use strict';
// RJ Studio bounded coding worker. Run locally/CI with explicit project access.
// It never runs AI-generated shell commands; only a small allowlist of tests.
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const ROOT = path.resolve(process.env.RJ_PROJECT_ROOT || path.join(__dirname, '..'));
const QUEUE = path.resolve(process.env.RJ_TASK_QUEUE || path.join(__dirname, 'agent-tasks.json'));
const AI_BASE_URL = (process.env.AI_BASE_URL || '').replace(/\/$/, '');
const AI_API_KEY = process.env.AI_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || '';
const MAX_TASKS = Math.max(1, Math.min(20, Number(process.env.RJ_MAX_TASKS || 3)));
const ALLOWED_EXT = new Set(['.js','.json','.md','.html','.css','.java','.xml','.gradle','.properties']);
const FORBIDDEN = /(^|\/)(\.env|secrets?|credentials?|keystore|\.git)(\/|$)|(^|\/)local\.properties$/i;
const TESTS = {
  'server-syntax': () => run(process.execPath, ['--check', path.join(ROOT,'server','server.js')]),
  'worker-syntax': () => run(process.execPath, ['--check', path.join(ROOT,'server','agent-worker.js')]),
  'server-smoke': () => run(process.execPath, [path.join(ROOT,'server','smoke-test.js')], { ...process.env, RJ_TEST_ONLY:'1' })
};
function run(cmd,args,env=process.env) {
  const r=spawnSync(cmd,args,{cwd:ROOT,env,encoding:'utf8',timeout:60000,maxBuffer:1024*1024});
  return {ok:r.status===0, command:[cmd,...args].join(' '), stdout:(r.stdout||'').slice(-12000), stderr:(r.stderr||'').slice(-12000), status:r.status};
}
function loadQueue(){ return JSON.parse(fs.readFileSync(QUEUE,'utf8')); }
function saveQueue(q){ fs.writeFileSync(QUEUE,JSON.stringify(q,null,2)+'\n'); }
function safePath(rel){
  if(typeof rel!=='string' || !rel || path.isAbsolute(rel) || rel.includes('\\')) throw new Error('Unsafe file path');
  const norm=path.posix.normalize(rel);
  if(norm==='..'||norm.startsWith('../')||FORBIDDEN.test(norm)) throw new Error('Path is not allowed: '+rel);
  const full=path.resolve(ROOT,norm);
  if(!full.startsWith(ROOT+path.sep)) throw new Error('Path escapes project');
  if(!ALLOWED_EXT.has(path.extname(full))) throw new Error('File type not allowed: '+rel);
  return full;
}
async function ask(prompt){
  if(!AI_BASE_URL||!AI_API_KEY||!AI_MODEL) throw new Error('Set AI_BASE_URL, AI_API_KEY, AI_MODEL to enable the worker.');
  const endpoint=AI_BASE_URL.endsWith('/chat/completions')?AI_BASE_URL:`${AI_BASE_URL}/chat/completions`;
  const res=await fetch(endpoint,{method:'POST',headers:{Authorization:`Bearer ${AI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:AI_MODEL,temperature:0.1,messages:[{role:'system',content:`You are RJ Studio's autonomous coding worker. Return ONLY valid JSON, no markdown: {"summary":"...","edits":[{"path":"relative/path","content":"complete replacement file content"}],"tests":["server-syntax"|"worker-syntax"|"server-smoke"],"blocked":false,"blocker":""}. Work on ONE task at a time. Keep changes minimal. Never edit .env, credentials, keystores, workflow secrets or files outside the project. Do not add arbitrary shell commands, dependencies, remote code execution, surveillance, credential theft, or unsafe functionality. Do not claim tests passed unless supplied results prove it. Prefer documentation and simple safe fixes. If uncertain, return no edits and set blocked=true with a reason.`},{role:'user',content:prompt}] }),signal:AbortSignal.timeout(90000)});
  const raw=await res.text(); if(!res.ok) throw new Error('AI provider HTTP '+res.status+': '+raw.slice(0,500));
  let outer; try{outer=JSON.parse(raw)}catch{throw new Error('AI provider returned invalid JSON envelope')}
  const content=outer?.choices?.[0]?.message?.content; if(typeof content!=='string') throw new Error('AI response missing message content');
  let obj; try{obj=JSON.parse(content)}catch{const m=content.match(/\{[\s\S]*\}/); if(!m)throw new Error('AI did not return JSON'); obj=JSON.parse(m[0]);}
  if(!obj||!Array.isArray(obj.edits)||!Array.isArray(obj.tests)) throw new Error('AI JSON missing edits/tests arrays');
  return obj;
}
async function main(){
  if(!fs.existsSync(QUEUE)) throw new Error('Task queue not found: '+QUEUE);
  const q=loadQueue(); q.tasks=q.tasks||[]; let processed=0;
  while(processed<MAX_TASKS){
    const task=q.tasks.find(t=>t.status==='pending'); if(!task) break;
    task.status='running'; task.startedAt=new Date().toISOString(); saveQueue(q);
    const report={taskId:task.id, title:task.title, startedAt:task.startedAt, edits:[], tests:[], status:'blocked'};
    try{
      const prompt=`Project root: ${ROOT}\nTask ID: ${task.id}\nTitle: ${task.title}\nDescription: ${task.description}\nAcceptance criteria: ${(task.acceptance||[]).join('; ')}\nRelevant files:\n${(task.files||[]).map(rel=>{try{return '\n--- '+rel+' ---\n'+fs.readFileSync(safePath(rel),'utf8').slice(0,16000)}catch(e){return '\n--- '+rel+' ---\n[not readable: '+e.message+']'}}).join('\n')}\nReturn a minimal safe patch as complete replacement content. If task cannot be safely completed, block it.`;
      const result=await ask(prompt); report.summary=String(result.summary||''); report.blocker=String(result.blocker||'');
      if(result.blocked){task.status='blocked';report.status='blocked';}
      else {
        const backups=[];
        try{
          for(const edit of result.edits){
            const full=safePath(edit.path); if(typeof edit.content!=='string')throw new Error('Edit content must be text');
            if(Buffer.byteLength(edit.content)>300000)throw new Error('Single edit exceeds 300KB limit');
            const existed=fs.existsSync(full); const old=existed?fs.readFileSync(full):null;
            const backup=full+'.rj-agent-backup'; if(existed)fs.writeFileSync(backup,old);
            backups.push({full,existed,old,backup}); fs.mkdirSync(path.dirname(full),{recursive:true}); fs.writeFileSync(full,edit.content,'utf8'); report.edits.push(edit.path);
          }
          let allOk=true;
          for(const name of result.tests){ if(!Object.hasOwn(TESTS,name)){report.tests.push({name,ok:false,error:'Test not allowlisted'});allOk=false;continue;} const tr=TESTS[name]();report.tests.push({name,...tr});if(!tr.ok)allOk=false; }
          if(!result.tests.length){allOk=false;report.tests.push({name:'tests-required',ok:false,error:'AI proposed no tests'});}
          if(!allOk){ for(const b of backups){if(b.existed)fs.writeFileSync(b.full,b.old);else if(fs.existsSync(b.full))fs.unlinkSync(b.full);if(fs.existsSync(b.backup))fs.unlinkSync(b.backup);} task.status='failed';report.status='rolled_back';report.blocker='One or more allowlisted tests failed; changes rolled back.'; }
          else { for(const b of backups)if(fs.existsSync(b.backup))fs.unlinkSync(b.backup);task.status='completed';task.completedAt=new Date().toISOString();report.status='completed'; }
        }catch(e){for(const b of backups.reverse()){try{if(b.existed)fs.writeFileSync(b.full,b.old);else if(fs.existsSync(b.full))fs.unlinkSync(b.full);if(fs.existsSync(b.backup))fs.unlinkSync(b.backup)}catch{}}throw e;}
      }
    }catch(e){task.status='failed';report.status='failed';report.blocker=e.message;}
    task.lastReport=report; task.finishedAt=new Date().toISOString();
    q.reports=q.reports||[]; q.reports.push(report); saveQueue(q); console.log(JSON.stringify(report,null,2)); processed++;
  }
  console.log(`Worker finished: ${processed} task(s) processed. Pending: ${q.tasks.filter(t=>t.status==='pending').length}`);
}
main().catch(e=>{console.error('RJ agent worker stopped:',e.message);process.exitCode=1;});
