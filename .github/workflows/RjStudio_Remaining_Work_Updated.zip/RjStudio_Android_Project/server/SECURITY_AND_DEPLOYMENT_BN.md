# RJ Studio সার্ভার: নিরাপত্তা ও ডিপ্লয়মেন্ট চেকলিস্ট

## চালানোর আগে
- Node.js 20+ ব্যবহার করুন।
- `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, `RJ_GATEWAY_TOKEN` hosting secrets-এ সেট করুন।
- `NODE_ENV=production` হলে `RJ_GATEWAY_TOKEN` না থাকলে সার্ভার চালু হবে না।
- দীর্ঘ, এলোমেলো gateway token তৈরি করুন; provider API key কখনো GitHub, APK, HTML বা চ্যাটে hard-code করবেন না। client gateway token-ও APK-তে hard-code করবেন না; অ্যাপের সেটিংসে ব্যবহারকারী নিজে দিলে সেটি এই ডিভাইসের session storage-এ থাকবে এবং এটি provider API key-এর বিকল্প নয়।
- `CORS_ORIGIN`-এ নির্দিষ্ট origin দিন, wildcard নয়। APK-এর WebView যদি `file://` থেকে fetch করে এবং request-এর Origin `null` হয়, কেবল সেই পরীক্ষার ক্ষেত্রে `CORS_ORIGIN=null` সেট করা যায়; এটি অতিরিক্ত ঝুঁকি তৈরি করে, তাই gateway token, rate limit এবং HTTPS বাধ্যতামূলক রাখুন। সম্ভব হলে পরবর্তীতে Android WebView Asset Loader-এর HTTPS origin ব্যবহার করুন। CORS নিজে authentication নয়।
- HTTPS reverse proxy/host ব্যবহার করুন। এই Node server-কে সরাসরি public internet-এ TLS ছাড়া প্রকাশ করবেন না।

## লোকাল পরীক্ষা
```sh
node --check server.js
node --check agent-worker.js
node smoke-test.js
```

## লোকাল চালানো
পরীক্ষার জন্য environment variables সেট করে `node server.js` চালান। Production-এ secrets hosting dashboard-এ দিন; `.env.example` নিজে থেকে লোড হয় না।

## Docker
এই ফোল্ডার থেকে secret-গুলো environment-এ সেট করে `docker compose up --build -d` চালান। `docker-compose.yml`-এর required variable না থাকলে Compose চালু হবে না।

## সীমাবদ্ধতা
- Gateway-এর `/health` endpoint কেবল process/configuration status দেখায়; AI provider সফলভাবে উত্তর দেবে তার নিশ্চয়তা নয়।
- Gateway AI-কে উত্তর/পরিকল্পনা করতে বলে; নিজে generated code execute করে না।
- `agent-worker.js` সীমিত file types ও allowlisted tests-সহ একটি prototype worker। Production autonomous coding-এর আগে আলাদা sandbox/container, per-task timeout, audit logs, Git isolation, dependency policy এবং human approval gate দরকার।
- In-memory rate limit একাধিক instance-এ ভাগ হয় না এবং process restart-এ reset হয়। Production-এ shared rate limiter ও monitoring যোগ করুন।
- API provider-এর free tier/availability নিশ্চিত নয়।
- APK build ও বাস্তব Android ফোন পরীক্ষা এই Node.js smoke test-এর অন্তর্ভুক্ত নয়।


## Android WebView CORS সেটিং

Bundled `file:///android_asset/index.html` UI সাধারণত `Origin: null` পাঠায়। তাই Android APK থেকে Gateway ও Task API ব্যবহার করতে `.env`-এ `CORS_ORIGIN=null` এবং `TASKS_CORS_ORIGIN=null` ব্যবহার করতে হবে। এটি অবশ্যই আলাদা শক্তিশালী `RJ_GATEWAY_TOKEN` ও `RJ_TASKS_TOKEN`-এর সঙ্গে ব্যবহার করুন। `*` ব্যবহার করবেন না। যদি আলাদা HTTPS ওয়েব UI থাকে, `null`-এর বদলে তার exact origin দিন।
