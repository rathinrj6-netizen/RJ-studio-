'use strict';
// Minimal dependency-free, OpenAI-compatible AI gateway for RJ Studio.
// It deliberately does NOT execute arbitrary generated code or shell commands.
const http = require('node:http');
const { URL } = require('node:url');
const PORT = Number(process.env.PORT || 8787);
const AI_BASE_URL = (process.env.AI_BASE_URL || '').replace(/\/$/, '');
const AI_API_KEY = process.env.AI_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || '';
const GATEWAY_TOKEN = process.env.RJ_GATEWAY_TOKEN || '';
const CORS_ORIGIN = (process.env.CORS_ORIGIN || '').trim();
if (process.env.NODE_ENV === 'production' && !GATEWAY_TOKEN) {
  console.error('Refusing production start: RJ_GATEWAY_TOKEN must be configured.');
  process.exit(1);
}
const MAX_BODY = 64 * 1024;
const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 30;
const buckets = new Map();

function send(req, res, status, data) {
  const requestOrigin = req.headers.origin;
  // Only echo CORS headers for the one explicitly configured origin.
  // Set CORS_ORIGIN=null only when the bundled file:// WebView sends Origin: null,
  // and keep RJ_GATEWAY_TOKEN enabled. CORS is not authentication.
  const corsAllowed = Boolean(CORS_ORIGIN && requestOrigin && requestOrigin === CORS_ORIGIN);
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Vary': 'Origin',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'X-Frame-Options': 'DENY'
  };
  if (corsAllowed) headers['Access-Control-Allow-Origin'] = CORS_ORIGIN;
  res.writeHead(status, headers);
  res.end(status === 204 ? undefined : JSON.stringify(data));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (Buffer.byteLength(body) > MAX_BODY) {
        reject(Object.assign(new Error('Request too large'), { status: 413 }));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(Object.assign(new Error('Invalid JSON body'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function authorized(req) {
  if (!GATEWAY_TOKEN) return process.env.NODE_ENV !== 'production';
  const header = req.headers.authorization || '';
  const supplied = header.startsWith('Bearer ') ? header.slice(7) : '';
  // Token comparison is constant-time for equal-length values.
  const a = Buffer.from(supplied); const b = Buffer.from(GATEWAY_TOKEN);
  return a.length === b.length && require('node:crypto').timingSafeEqual(a, b);
}
function rateLimited(req) {
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  let b = buckets.get(ip);
  if (!b || now - b.start >= WINDOW_MS) b = { start: now, count: 0 };
  b.count++;
  buckets.set(ip, b);
  return b.count > MAX_REQUESTS_PER_WINDOW;
}
const systemPrompt = `You are RJ Studio's persistent multi-role work assistant. Reply in the user's language, preferably Bengali. Apply all role mindsets: APK/build diagnosis; design and accessibility; Bengali voice support; safe updates and rollback; writing/translation; step-by-step teaching; careful coding/debugging; image-grounded observations; source-aware research; task planning; checked mathematics; Android/device-support boundaries; authorized defensive security; code-security review; and cross-task coordination that tracks pending work, blockers, progress, and next actions.

Mandatory work loop: inspect available evidence; distinguish implemented features from mockups; prioritize security/build/data-loss blockers; make a small plan with acceptance criteria; propose small reviewable changes; run relevant tests only when tools are actually available; diagnose failures from logs; review for secrets/privacy/destructive side effects; report exact status as DONE, PARTIAL, BLOCKED, or NOT RUN. Never claim you ran code, changed files, deployed a server, controlled a phone, or built an APK unless a tool result proves it. This gateway does not execute generated code, modify project files, run tests, or persist a task queue.

Safety: work only on systems the user owns or is authorized to test. Never request API keys/passwords in chat. Keep secrets server-side. Do not provide unauthorized intrusion or security bypass. Do not send SMS/calls, read or upload private files, control other apps, deploy, release-sign, activate paid services, delete data, or perform external uploads without explicit approval. If access, credentials, SDK, device, or tools are missing, clearly say what is blocked and provide a safe next step. Do not promise autonomous always-on behavior when no worker/tool is connected.`;
async function askAI(userText, mode) {
  if (!AI_BASE_URL || !AI_API_KEY || !AI_MODEL) {
    const e = new Error('AI backend is not configured. Set AI_BASE_URL, AI_API_KEY and AI_MODEL on the server.');
    e.status = 503;
    throw e;
  }
  const endpoint = AI_BASE_URL.endsWith('/chat/completions') ? AI_BASE_URL : `${AI_BASE_URL}/chat/completions`;
  const taskPrompt = mode === 'plan'
    ? `Create a step-by-step implementation plan. Separate verified facts, assumptions, tests and blockers. User request: ${userText}`
    : userText;
  const upstream = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${AI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: AI_MODEL, temperature: 0.2, messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: taskPrompt }] }),
    signal: AbortSignal.timeout(45_000)
  });
  const data = await upstream.json().catch(() => ({}));
  if (!upstream.ok) {
    const e = new Error(`AI provider returned HTTP ${upstream.status}`);
    e.status = 502;
    throw e;
  }
  const answer = data?.choices?.[0]?.message?.content;
  if (typeof answer !== 'string' || !answer.trim()) {
    const e = new Error('AI provider response did not contain a text answer.'); e.status = 502; throw e;
  }
  return answer;
}
const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(req, res, 204, {});
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/health') {
    return send(req, res, 200, { ok: true, service: 'rj-studio-ai-gateway', aiConfigured: Boolean(AI_BASE_URL && AI_API_KEY && AI_MODEL), codeExecution: false, timestamp: new Date().toISOString() });
  }
  if (req.method !== 'POST' || !['/api/chat', '/api/agent/plan'].includes(url.pathname)) {
    return send(req, res, 404, { error: 'Not found' });
  }
  if (!authorized(req)) return send(req, res, 401, { error: 'Unauthorized' });
  if (rateLimited(req)) return send(req, res, 429, { error: 'Rate limit exceeded. Try again in a minute.' });
  try {
    const body = await readBody(req);
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    if (!prompt) return send(req, res, 400, { error: 'prompt is required' });
    if (prompt.length > 20_000) return send(req, res, 413, { error: 'prompt is too long' });
    const answer = await askAI(prompt, url.pathname.endsWith('/plan') ? 'plan' : 'chat');
    return send(req, res, 200, { ok: true, answer, mode: url.pathname.endsWith('/plan') ? 'plan' : 'chat' });
  } catch (e) {
    const status = Number.isInteger(e.status) ? e.status : 500;
    // Never return upstream response bodies or secrets to clients.
    const publicMessage = status >= 500 ? (status === 503 ? e.message : 'AI provider request failed. Check server logs.') : (e.message || 'Request failed');
    if (status >= 500) console.error('[gateway]', status, e.message);
    return send(req, res, status, { error: publicMessage });
  }
});
server.listen(PORT, '0.0.0.0', () => console.log(`RJ Studio AI gateway listening on ${PORT}; AI configured: ${Boolean(AI_BASE_URL && AI_API_KEY && AI_MODEL)}; gateway auth: ${Boolean(GATEWAY_TOKEN)}`));
