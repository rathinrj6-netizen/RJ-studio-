'use strict';
const { spawn } = require('node:child_process');
const port = 19000 + Math.floor(Math.random() * 1000);
const child = spawn(process.execPath, ['server.js'], { cwd: __dirname, env: { ...process.env, PORT: String(port), AI_BASE_URL: '', AI_API_KEY: '', AI_MODEL: '' }, stdio: 'ignore' });
const base = `http://127.0.0.1:${port}`;
(async () => {
  try {
    let ready = false;
    for (let i = 0; i < 40; i++) {
      try { const r = await fetch(`${base}/health`); if (r.ok) { ready = true; break; } } catch {}
      await new Promise(r => setTimeout(r, 100));
    }
    if (!ready) throw new Error('health endpoint did not start');
    const health = await (await fetch(`${base}/health`)).json();
    if (health.service !== 'rj-studio-ai-gateway' || health.aiConfigured !== false || health.codeExecution !== false) throw new Error('unexpected health response');
    const empty = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({}) });
    if (empty.status !== 400) throw new Error(`expected missing prompt 400, got ${empty.status}`);
    const chat = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: 'test' }) });
    if (chat.status !== 503) throw new Error(`expected unconfigured AI to return 503, got ${chat.status}`);
    const missing = await fetch(`${base}/not-found`);
    if (missing.status !== 404) throw new Error(`expected 404, got ${missing.status}`);
    child.kill('SIGTERM');
    const authPort = port + 1001;
    const authChild = spawn(process.execPath, ['server.js'], { cwd: __dirname, env: { ...process.env, PORT: String(authPort), AI_BASE_URL: '', AI_API_KEY: '', AI_MODEL: '', RJ_GATEWAY_TOKEN: 'smoke-test-secret' }, stdio: 'ignore' });
    try {
      const authBase = `http://127.0.0.1:${authPort}`;
      let authReady = false;
      for (let i = 0; i < 40; i++) { try { if ((await fetch(`${authBase}/health`)).ok) { authReady = true; break; } } catch {} await new Promise(r => setTimeout(r, 100)); }
      if (!authReady) throw new Error('authenticated gateway did not start');
      const payload = { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: 'test' }) };
      const denied = await fetch(`${authBase}/api/chat`, payload);
      if (denied.status !== 401) throw new Error(`expected missing token 401, got ${denied.status}`);
      const allowed = await fetch(`${authBase}/api/chat`, { ...payload, headers: { ...payload.headers, authorization: 'Bearer smoke-test-secret' } });
      if (allowed.status !== 503) throw new Error(`expected authorized but unconfigured AI 503, got ${allowed.status}`);
    } finally { authChild.kill('SIGTERM'); }
    const corsPort = port + 1002;
    const corsChild = spawn(process.execPath, ['server.js'], { cwd: __dirname, env: { ...process.env, PORT: String(corsPort), AI_BASE_URL: '', AI_API_KEY: '', AI_MODEL: '', RJ_GATEWAY_TOKEN: 'smoke-test-secret', CORS_ORIGIN: 'null' }, stdio: 'ignore' });
    try {
      const corsBase = `http://127.0.0.1:${corsPort}`;
      let corsReady = false;
      for (let i = 0; i < 40; i++) { try { if ((await fetch(`${corsBase}/health`)).ok) { corsReady = true; break; } } catch {} await new Promise(r => setTimeout(r, 100)); }
      if (!corsReady) throw new Error('CORS gateway did not start');
      const allowedOrigin = await fetch(`${corsBase}/health`, { headers: { origin: 'null' } });
      if (allowedOrigin.headers.get('access-control-allow-origin') !== 'null') throw new Error('expected CORS origin null to be allowed');
      const deniedOrigin = await fetch(`${corsBase}/health`, { headers: { origin: 'https://evil.example' } });
      if (deniedOrigin.headers.has('access-control-allow-origin')) throw new Error('unexpected CORS permission for unconfigured origin');
      const preflight = await fetch(`${corsBase}/api/chat`, { method: 'OPTIONS', headers: { origin: 'null', 'access-control-request-method': 'POST', 'access-control-request-headers': 'content-type,authorization' } });
      if (preflight.status !== 204 || preflight.headers.get('access-control-allow-origin') !== 'null') throw new Error('CORS preflight failed');
    } finally { corsChild.kill('SIGTERM'); }
    console.log('PASS: health, prompt validation, missing AI config, 404, gateway token auth, and exact CORS origin tests');
  } catch (e) { console.error('FAIL:', e.message); process.exitCode = 1; }
  finally { child.kill('SIGTERM'); }
})();
