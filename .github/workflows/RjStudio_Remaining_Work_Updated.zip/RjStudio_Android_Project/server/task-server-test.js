'use strict';
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
(async()=>{
 const port=19000+Math.floor(Math.random()*1000), token='test-task-token', file=path.join(os.tmpdir(),`rj-tasks-${process.pid}.json`);
 const child=spawn(process.execPath,['task-server.js'],{cwd:__dirname,env:{...process.env,NODE_ENV:'production',TASK_PORT:String(port),RJ_TASKS_TOKEN:token,TASKS_CORS_ORIGIN:'null',RJ_TASKS_FILE:file},stdio:['ignore','ignore','pipe']});
 let err='';child.stderr.on('data',d=>err+=d); const base=`http://127.0.0.1:${port}`;
 async function wait(){for(let i=0;i<60;i++){try{const r=await fetch(base+'/health');if(r.ok)return;}catch{} await new Promise(r=>setTimeout(r,100));}throw Error('server did not start '+err);}
 try {await wait();let pre=await fetch(base+'/api/tasks',{method:'OPTIONS',headers:{Origin:'null','Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'authorization,content-type'}});assert.equal(pre.status,204);assert.equal(pre.headers.get('access-control-allow-origin'),'null');let r=await fetch(base+'/api/tasks');assert.equal(r.status,401);const h={Authorization:`Bearer ${token}`,'Content-Type':'application/json'};
 r=await fetch(base+'/api/tasks',{method:'POST',headers:h,body:JSON.stringify({title:'Test task',description:'test'})});assert.equal(r.status,201);const created=(await r.json()).task;
 r=await fetch(base+'/api/tasks',{headers:h});assert.equal(r.status,200);assert.equal((await r.json()).tasks.length,1);
 r=await fetch(base+'/api/tasks/'+created.id,{method:'PATCH',headers:h,body:JSON.stringify({status:'done'})});assert.equal(r.status,200);assert.equal((await r.json()).task.status,'done');
 r=await fetch(base+'/api/tasks/'+created.id,{method:'PATCH',headers:h,body:JSON.stringify({status:'not-a-status'})});assert.equal(r.status,400);
 console.log('PASS: task health, null-origin CORS preflight, auth, create/list/update, invalid status');
 } finally {child.kill('SIGTERM');try{fs.unlinkSync(file)}catch{} }
})().catch(e=>{console.error(e);process.exit(1)});
