# RJ Studio AI Gateway (বাংলা)

এটি dependency-free Node.js সার্ভার। `/health`, `/api/chat` এবং `/api/agent/plan` endpoint দেয়। এটি OpenAI-compatible Chat Completions API-র সঙ্গে সংযোগ করতে পারে।

## চালানো

1. Node.js 20 বা নতুন সংস্করণ ইনস্টল করুন।
2. `server/.env.example` দেখে hosting dashboard-এ `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL` এবং প্রয়োজনে `PORT`/`CORS_ORIGIN` environment variables সেট করুন। `.env.example` নিজে থেকে লোড হয় না; secret hosting-এর environment settings-এ দিতে হবে।
3. `node server.js` চালান (server ফোল্ডারের ভেতর থেকে)।
4. `GET /health` পরীক্ষা করুন। `aiConfigured: true` মানে শুধু কনফিগারেশন উপস্থিত—AI provider-এর সফল অনুরোধের নিশ্চয়তা নয়।
5. `POST /api/chat` বা `POST /api/agent/plan`-এ JSON পাঠান, যেমন `{"prompt":"আমার Android build error বিশ্লেষণ করো"}`।

## নিরাপত্তা ও সীমা

- API key শুধু সার্ভারে থাকবে; APK/HTML-এ বসাবেন না।
- এই সংস্করণ ইচ্ছাকৃতভাবে generated code চালায় না, ফাইল বদলায় না, APK build করে না। এটি AI উত্তর/পরিকল্পনা দেয় মাত্র। বাস্তব coding agent-এর জন্য আলাদা sandbox, সীমিত workspace, অনুমোদন-নীতি, audit log এবং test runner দরকার।
- `CORS_ORIGIN=*` প্রাথমিক পরীক্ষার জন্য; production-এ নিজের নির্দিষ্ট origin দিন। Authentication/rate limit-এর production-grade ব্যবস্থা ও HTTPS hosting যোগ করার আগে জনসাধারণের জন্য উন্মুক্ত করবেন না। In-memory rate limit একাধিক server instance-এ ভাগ হয় না।
- Free hosting/API-তে সীমা, sleep, quota বা বিল আসতে পারে। বিনামূল্যে চলার নিশ্চয়তা নেই।


## সীমাবদ্ধ স্বয়ংক্রিয় Coding Worker

`agent-worker.js` একটি ছোট, সীমাবদ্ধ কোডিং-এজেন্ট রানার। এটি নিজে থেকে এই ChatGPT পরিবেশে বা ব্যবহারকারীর ফোনে সারাদিন চালু থাকে না। চালু সার্ভার/কম্পিউটারে Node.js ও অনুমোদিত AI provider credentials সেট করে চালাতে হয়।

### চালানোর ধাপ

1. এই ফোল্ডারে `npm` dependency লাগবে না; Node.js 18+ দরকার।
2. পরিবেশে `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL` সেট করুন। এগুলো কখনো অ্যাপ বা রিপোজিটরিতে লিখবেন না।
3. প্রজেক্টের মূল ফোল্ডার থেকে চালান: `node server/agent-worker.js`
4. ডিফল্টে এক রান-এ সর্বোচ্চ ৩টি কাজ; `RJ_MAX_TASKS=1` দিয়ে কমানো যায়।
5. ফলাফল `server/agent-tasks.json`-এ সংরক্ষিত হয়।

Worker শুধুমাত্র নির্দিষ্ট ফাইল-টাইপে কাজ করে, গোপন ফাইল/`.env`/keystore নিষিদ্ধ করে এবং AI-র দেওয়া shell command চালায় না। পরীক্ষার তালিকা একটি allowlist। কোনো পরীক্ষা ব্যর্থ হলে ওই task-এর ফাইল পরিবর্তন rollback করা হয়। তবুও বাস্তব প্রজেক্টে চালানোর আগে Git branch/backup ব্যবহার করুন এবং পরিবর্তন review করুন।

**গুরুত্বপূর্ণ:** এটি unattended, production-grade, সর্বক্ষণ চালু autonomous service নয়। AI provider-এর কনফিগারেশন, কম্পিউটার/CI runner, প্রকৃত Android SDK/Gradle, credentials, বিল্ড লগ এবং ফোন পরীক্ষা এখনও আলাদা করে প্রয়োজন। কোনো task `completed` হলেই APK বা Android device test সফল হয়েছে বোঝায় না।


আরও বিস্তারিত চালানো ও নিরাপত্তা চেকলিস্ট: `SECURITY_AND_DEPLOYMENT_BN.md`। `npm test` বা `node smoke-test.js` দিয়ে লোকাল smoke test চালান।


## সম্পূর্ণ সার্ভার স্ট্যাক

সার্ভারের উপাদান, Docker gateway/ঐচ্ছিক worker চালানো এবং এখনও সংযুক্ত নয় এমন অংশের তালিকার জন্য `SERVER_STACK_BN.md` দেখুন।

## আলাদা Task Server (নতুন)

AI Gateway-এর বাইরে অসমাপ্ত কাজ সংরক্ষণের জন্য আলাদা authenticated Task API আছে। `task-server.js`-এ `/health`, `GET /api/tasks`, `POST /api/tasks`, এবং `PATCH /api/tasks/:id` endpoint রয়েছে। Production-এ `RJ_TASKS_TOKEN` আবশ্যক; এটি `RJ_GATEWAY_TOKEN` থেকে আলাদা random secret রাখুন। Docker Compose-এ `rj-studio-task-server` সার্ভিস এবং persistent `rj-tasks-data` volume যোগ করা হয়েছে।

- `GET /api/tasks` — কাজের তালিকা
- `POST /api/tasks` JSON: `{"title":"...","description":"..."}` — কাজ যোগ
- `PATCH /api/tasks/<id>` JSON: `{"status":"in_progress"}` — status বদল; অনুমোদিত status: `pending`, `in_progress`, `done`, `blocked`
- সব `/api/tasks` অনুরোধে `Authorization: Bearer <RJ_TASKS_TOKEN>` দিতে হবে।
- লোকালি পরীক্ষা: `npm run check && npm test`

এই Task API এখনও Android UI-তে wire করা হয়নি; অ্যাপ থেকে ব্যবহার করতে হলে endpoint URL ও task token ব্যবস্থাপনা নিরাপদভাবে সংযুক্ত করতে হবে।
