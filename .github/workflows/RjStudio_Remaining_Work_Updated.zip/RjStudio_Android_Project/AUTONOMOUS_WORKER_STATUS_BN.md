# RJ Studio Coding Worker — অবস্থা

এই আপডেটে সীমাবদ্ধ task-queue-ভিত্তিক coding worker যোগ হয়েছে।

- `server/agent-worker.js`: AI থেকে structured JSON patch চায়, নির্দিষ্ট ফাইলের সীমা মানে, শুধু allowlisted test চালায় এবং পরীক্ষায় ব্যর্থ হলে ফাইল rollback করে।
- `server/agent-tasks.json`: নিরাপত্তা, ডকুমেন্টেশন, smoke test এবং Android review-এর প্রাথমিক queue।
- `server/README-BN.md`: চালানোর নির্দেশনা ও সীমাবদ্ধতা।

## যা এখনো স্বয়ংক্রিয় নয়
- AI provider credentials সেট করা ও worker চালু রাখা।
- GitHub-এ push/deploy বা Android APK build চালানো।
- Android SDK-র compile এবং বাস্তব ফোনে পরীক্ষা।
- ২৪/৭ uptime, retry scheduler, multi-user authentication/authorization-এর পূর্ণ production hardening।

Worker চালাতে Node.js 18+ এবং `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL` environment variable দরকার। কোনো secret source code বা Android app-এ রাখবেন না।
