# RJ Studio — আলাদা Earn & Monetization সেটিংস

Android WebView UI-তে `Earn & Monetization` নামে আলাদা প্যানেল যোগ করা হয়েছে। এতে আছে:
- Monetization control preference
- AdMob ও AdSense setup status preference
- ডিজিটাল সেবা বিক্রির preference
- পেমেন্ট সংযোগের অবস্থা (এখনো সংযুক্ত নয়)
- USD আয়ের ম্যানুয়াল নোট ফিল্ড
- সেটিংস সংরক্ষণ ও রিসেট
- Google AdMob ও AdSense-এর অফিসিয়াল পোর্টালের লিংক

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এই প্যানেল কেবল UI ও লোকাল সেটিংস। এটি নিজে থেকে বিজ্ঞাপন চালু করে না, Google অ্যাকাউন্ট সংযুক্ত করে না, পেমেন্ট নেয় না, বা লাইভ আয় আনে না। USD ফিল্ডটি ম্যানুয়াল নোট—এটি কোনো যাচাইকৃত/লাইভ আয়ের হিসাব নয়। বাস্তব monetization-এর জন্য অ্যাকাউন্ট অনুমোদন, SDK/ওয়েবসাইট ইন্টিগ্রেশন, প্রযোজ্য নীতি ও পেমেন্ট সেটআপ আলাদাভাবে করতে হবে।

## যাচাই
HTML parse এবং server smoke tests চালানো হয়েছে। Android Gradle build, APK build ও বাস্তব ডিভাইস পরীক্ষা এখনো করা হয়নি।
