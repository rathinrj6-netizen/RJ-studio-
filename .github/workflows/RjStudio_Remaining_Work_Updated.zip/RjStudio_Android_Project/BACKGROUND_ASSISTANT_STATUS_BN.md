# RJ Studio Background Assistant — অবস্থা

## এই আপডেটে যোগ হয়েছে
- Android foreground service-এর স্থায়ী status notification।
- Web UI-তে কাজ যোগ করা, কাজ সম্পন্ন/বাতিল চিহ্নিত করা এবং তালিকা দেখার UI।
- Android SharedPreferences-এ task JSON সংরক্ষণ এবং app reopen-এ পড়ার bridge।
- সার্ভিস চালু থাকলে নোটিফিকেশনে অপেক্ষমাণ কাজের সংখ্যা refresh করার ব্যবস্থা।
- কাজের তালিকা AI দ্বারা বাস্তবে সম্পাদিত হয় না—UI-তে সীমাবদ্ধতা স্পষ্ট করে দেখানো হয়েছে।

## এখনো বাকি
1. GitHub Actions-এ Android build চালিয়ে APK artifact যাচাই।
2. বাস্তব Android ফোনে সার্ভিস start/stop, app restart, notification permission এবং battery optimization পরীক্ষা।
3. নিরাপদ HTTPS backend দিয়ে বাস্তব AI সংযোগ; API key কখনো APK-তে নয়।
4. অনুমতি-ভিত্তিক code editing/build execution workflow, error recovery ও audit log।
5. Release signing, privacy review এবং Google Login (আলাদা OAuth setup দরকার)।

## যাচাই
এই পরিবেশে Android SDK/Gradle ইনস্টল নেই, তাই APK compile বা device test দাবি করা হচ্ছে না। GitHub Actions workflow ব্যবহার করে build করতে হবে।
