# Rj Studio — Capability Plan (বাংলা)

## লক্ষ্য
Rj Studio-কে এমন একটি AI-সহায়ক অ্যাপে উন্নীত করা, যা প্রজেক্ট পরীক্ষা, বিল্ড লগ বিশ্লেষণ, ব্যবহারকারীর অনুমোদিত কোড সংশোধন, APK artifact তৈরি এবং স্পষ্ট অনুমতিতে নির্দিষ্ট ফোন-অ্যাকশন পরিচালনায় সাহায্য করে।

## বাস্তব অবস্থা
এই ডকুমেন্ট পরিকল্পনা; নিচের অসম্পূর্ণ বৈশিষ্ট্যগুলোকে বাস্তবে চালু বলে ধরে নেওয়া যাবে না। বর্তমান UI প্রোটোটাইপ, AI backend নেই, native phone-control service নেই এবং APK build এই প্যাকেজে চালানো/যাচাই করা হয়নি।

## মডিউল ও গ্রহণযোগ্যতার পরীক্ষা
- **Build Assistant:** ক্লাউড বিল্ড চালানোর নির্দেশনা, build status/artifact দেখানো; ভুল হলে log ও নির্দিষ্ট failure reason দেখাবে। গ্রহণযোগ্যতা: সফল/ব্যর্থ workflow—দুটিই সঠিকভাবে চিহ্নিত।
- **Repair Assistant:** প্রস্তাবিত diff দেখাবে; স্বয়ংক্রিয়ভাবে source বদলানোর আগে ব্যবহারকারীর অনুমতি চাইবে। গ্রহণযোগ্যতা: পরিবর্তনের আগে/পরে diff ও rollback নির্দেশনা।
- **AI Assistant:** backend থেকে উত্তর; API key কেবল server-side secret-এ। গ্রহণযোগ্যতা: key APK বা HTML-এ নেই, timeout/error handling আছে।
- **Phone Control Assistant:** কেবল Android-সমর্থিত কাজ, স্পষ্ট opt-in permission, Accessibility/অন্যান্য প্রয়োজনীয় native API এবং স্থায়ী disable ব্যবস্থা। গ্রহণযোগ্যতা: অনুমতি না দিলে কোনো নিয়ন্ত্রণ নয়; বন্ধ করলে কাজ বন্ধ।
- **Update Assistant:** সংস্করণ/চেঞ্জলগ জানাবে; ইনস্টল আপডেট ব্যবহারকারী নিশ্চিত করবেন। গ্রহণযোগ্যতা: যাচাইকৃত artifact ও সংস্করণ-তথ্য।
- **Quality Assistant:** build, install, launch, permission এবং crash পরীক্ষার রিপোর্ট। গ্রহণযোগ্যতা: পরীক্ষিত ও অপরীক্ষিত বিষয় আলাদা করে দেখানো।

## নিরাপত্তা সীমা
ব্যবহারকারীর স্পষ্ট অনুমতি ছাড়া ফোন নিয়ন্ত্রণ, গোপন নজরদারি, নিরাপত্তা পাশ কাটানো বা ব্যাকগ্রাউন্ডে গোপন কাজ নয়। Android-এর সংস্করণ, manufacturer ও permission অনুযায়ী সক্ষমতা বদলাতে পারে। কোনো বাগ নেই—এমন নিশ্চয়তা দেওয়া যাবে না; বাস্তব পরীক্ষা আবশ্যক।


## 2026-10-23 অগ্রগতি
- UI-তে Ethical Hacking Lab ও Code Security Scanner যোগ করা হয়েছে।
- কোড ডিভাইসেই pattern matching দিয়ে পরীক্ষা করে সাধারণ ঝুঁকির ইঙ্গিত দেখায়।
- প্রকৃত AI backend, autonomous code changes, device-level pentest ও APK build এখনো অসম্পূর্ণ; build/test workflow চালিয়ে যাচাই করতে হবে।
