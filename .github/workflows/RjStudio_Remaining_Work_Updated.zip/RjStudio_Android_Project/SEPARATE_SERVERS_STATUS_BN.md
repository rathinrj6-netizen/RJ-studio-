# RJ Studio — আলাদা সার্ভারভিত্তিক কাজের অবস্থা

## এই প্যাকেজে আলাদা সার্ভার

1. **AI Gateway (8787)** — OpenAI-compatible provider-এ chat/plan অনুরোধ পাঠায়; `RJ_GATEWAY_TOKEN` এবং provider-এর server-side API key লাগে।
2. **Task API (8788)** — আলাদা JSON store-এ কাজ তৈরি/দেখা/status update করে; `RJ_TASKS_TOKEN` আবশ্যক। Gateway token থেকে আলাদা token ব্যবহার করুন।
3. **Coding Worker** — ঐচ্ছিক ও bounded worker; শুধু নির্দিষ্ট allowlisted test চালায়/সীমাবদ্ধ ফাইল পরিবর্তন করে। এটি always-on autonomous agent নয়।
4. **Android build** — `.github/workflows/build-apk.yml`-এর আলাদা GitHub Actions job; এটি কোনো public build server নয় এবং GitHub-এ workflow চালানো না পর্যন্ত APK artifact নেই।

## চালানোর ধাপ

1. `server/.env.example` থেকে নিজের গোপন `.env` তৈরি করুন। কোনো আসল key GitHub/ZIP-এ commit করবেন না।
2. `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, `RJ_GATEWAY_TOKEN`, এবং আলাদা `RJ_TASKS_TOKEN` সেট করুন।
3. `cd server && docker compose up -d --build rj-studio-ai-gateway rj-studio-task-server` চালান। Docker/hosting দরকার।
4. `cd server && npm run check && npm test` দিয়ে local tests চালান।
5. APK build-এর জন্য Android project root-এ GitHub repository-তে push করে Actions → Build Rj Studio APK → Run workflow চালান। Successful হলে `RjStudio-debug-apk` artifact ডাউনলোড করুন।

## গুরুত্বপূর্ণ অসম্পূর্ণতা

- এই পরিবেশে বাস্তব provider credentials/hosting access নেই, তাই কোনো সার্ভার ইন্টারনেটে deploy করা হয়নি।
- Android app থেকে Task API-তে UI integration এখনও করা হয়নি; production app-এ shared static token embed করা নিরাপদ নয়। User authentication/proxy design লাগবে।
- APK তৈরি/ডিভাইসে পরীক্ষা করা হয়নি। Android SDK/Gradle build এই রানটিতে করা হয়নি।
- Voice control, always-on autonomous coding, phone-wide control, monetization/ad payments বাস্তব service-এ connected নয়। এগুলো আলাদা permissions, provider approval, integration ও device tests চায়।
- Task server local persistent JSON store ব্যবহার করে; production scale/multi-instance deployment-এর জন্য database, backup, TLS, monitoring, rate limiting এবং per-user authorization যোগ করা দরকার।
