# Rj Studio — ফোন থেকে APK তৈরি (বাংলা নির্দেশিকা)

## প্রকল্পের বর্তমান যাচাই
- Node.js source syntax, inline HTML JavaScript, JSON/XML, gateway smoke tests এবং task API tests সফল হয়েছে।
- Android SDK/Gradle build environment এই প্যাকেজ তৈরির পরিবেশে নেই; তাই এখানে APK compile বা install test করা হয়নি।
- AI gateway/task server-এর জন্য বৈধ hosting ও environment secrets না থাকায় বাস্তব AI উত্তর/remote task execution সক্রিয় নয়।

## GitHub Actions দিয়ে APK তৈরি
1. ZIP ফাইলটি Android ফোনে ডাউনলোড করে Extract করুন।
2. Extract করা `RjStudio_Android_Project` ফোল্ডারের ভেতরের ফাইলগুলো একটি GitHub repository-র root-এ আপলোড করুন—ফোল্ডারটির ভেতর আরেকটি একই নামে nested project যেন না থাকে।
3. Repository-র **Actions** tab খুলুন। প্রথমবার Actions চালু করতে বললে Enable করুন।
4. **Build Rj Studio APK** workflow নির্বাচন করে **Run workflow** চাপুন। অথবা `main`/`master` branch-এ push করলে workflow নিজে চলবে।
5. Build সফল হলে workflow run-এর নিচে **Artifacts** থেকে `RjStudio-debug-apk` ডাউনলোড করুন। ZIP-টি Extract করে `app-debug.apk` ইনস্টল করুন।
6. ফোনে ইনস্টল করার আগে Android-এর “Install unknown apps” অনুমতি চাইতে পারে। শুধু নিজের তৈরি ও বিশ্বাসযোগ্য APK-র জন্য অনুমতি দিন।

## AI সংযোগের সীমাবদ্ধতা
- শুধু APK তৈরি হলেই AI সার্ভার চালু হয় না। আলাদা HTTPS hosting-এ server deploy করে `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, `RJ_GATEWAY_TOKEN`, `RJ_TASKS_TOKEN` secrets সেট করতে হবে।
- Provider API key কখনো Android অ্যাপের মধ্যে hard-code করবেন না। Gateway/task token-ও প্রকাশ্য repository-তে commit করবেন না।
- Background Assistant বর্তমানে queued task-এর অবস্থা notification-এ দেখায়; এটি নিজে থেকে ফোনের সব অ্যাপ নিয়ন্ত্রণ করে না এবং নিজে AI code build/release করে না।

## যাচাইয়ের অবস্থা
`node tools/rj-12-tools/run-all.js` চালালে source checks এবং server tests চালানো যাবে। Android build সফল হয়েছে কি না তা কেবল GitHub Actions-এর build result ও APK artifact দিয়ে নিশ্চিত হবে।
