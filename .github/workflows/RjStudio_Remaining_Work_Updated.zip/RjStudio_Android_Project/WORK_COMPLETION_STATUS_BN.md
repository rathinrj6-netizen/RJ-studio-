# RJ Studio — কাজ সম্পন্ন ও বাকি থাকা অংশের যাচাই প্রতিবেদন

## এই প্যাকেজে বাস্তবে করা হয়েছে
- Android WebView UI-তে AI Gateway URL এবং Gateway access token-এর আলাদা সেটিংস যোগ করা হয়েছে।
- AI chat ও agent-plan request-এ `Authorization: Bearer ...` header পাঠানোর ব্যবস্থা যোগ হয়েছে; token APK-তে hard-code করা হয়নি।
- token `sessionStorage`-এ রাখা হয়, তাই app/webview session শেষ হলে আবার দিতে হতে পারে।
- Android `file://` WebView থেকে API fetch করার ক্ষেত্রে `Origin: null`-এর CORS নির্দেশনা deployment docs ও `.env.example`-এ স্পষ্ট করা হয়েছে।
- server smoke test-এ gateway token ছাড়া 401 এবং সঠিক token-সহ (কিন্তু AI config না থাকায়) 503 প্রত্যাশা পরীক্ষা যোগ হয়েছে।

## এই পরিবেশে চালানো পরীক্ষার ফল
- `node --check server.js`: PASS
- `node --check agent-worker.js`: PASS
- `node --check smoke-test.js`: PASS
- `node smoke-test.js`: PASS — health, prompt validation, missing AI configuration, 404, gateway token authentication
- `index.html` inline JavaScript syntax: PASS (2 script blocks)
- project XML parse: PASS
- project JSON parse: PASS
- ZIP integrity: PASS

## এখনও BLOCKED / NOT RUN
- **বাস্তব AI উত্তর:** `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`-এর বৈধ সার্ভার-side মান না থাকায় upstream AI-তে সংযোগ যাচাই করা যায়নি। Provider API key কখনো অ্যাপের মধ্যে দেবেন না।
- **সার্ভার প্রকাশ:** এই পরিবেশে কোনো hosting account বা deployment credentials নেই; তাই সার্ভার ইন্টারনেটে deploy করা হয়নি।
- **Android APK:** Android SDK/Gradle build tools এবং Gradle wrapper এই পরিবেশে নেই; তাই APK build/Java compile করা যায়নি। APK তৈরি হয়েছে বলে দাবি করা হচ্ছে না।
- **বাস্তব ফোন পরীক্ষা:** সংযুক্ত Android device/ADB নেই; notification, microphone, WebView networking বা background behavior ফোনে যাচাই করা হয়নি।
- **স্বয়ংক্রিয় কোডিং:** Worker bounded task runner; এটি সর্বক্ষণ চালু থাকে না, APK নিজে build/sign/release করে না, এবং task queue-র কাজগুলো বাস্তবে সম্পন্ন হয়েছে বলে ধরা যাবে না।
- **আয়/পেমেন্ট:** বিজ্ঞাপন বা payment account সংযুক্ত/অনুমোদিত নয়; কোনো আয় তৈরি হয়েছে বলে দাবি করা হচ্ছে না।

## চালানোর আগে জরুরি সেটআপ
1. Hosting provider-এ `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, `RJ_GATEWAY_TOKEN` environment secrets সেট করুন।
2. Android WebView-এর জন্য CORS সমস্যা হলে deployment guide অনুযায়ী সঠিক origin সেট করুন। `CORS_ORIGIN=null` কেবল প্রয়োজন হলে ব্যবহার করুন এবং শক্তিশালী gateway token/HTTPS বজায় রাখুন।
3. Android build করতে Android SDK/Gradle সহ পরিবেশে `assembleDebug` চালিয়ে build log পরীক্ষা করুন।
4. APK বাস্তব ফোনে ইনস্টল করে AI chat, token auth, voice, notification, persistence ও error handling পরীক্ষা করুন।


## 2026-10-24 — Task Server integration follow-up

- Added Task Server HTTPS URL and separate Task token fields in app Settings.
- Task list can load/create/update tasks through the authenticated Task API when configured; without it, local task storage remains as fallback.
- Remote tasks can be marked done or blocked. The app does not claim that queued tasks are automatically executed by AI.
- Updated Docker Compose and `.env.example` CORS defaults for bundled Android `file://` UI (`Origin: null`); token authentication remains required in production.
- Extended syntax checker to validate inline JavaScript in the app HTML.
- Verification: see `reports-12-tools-run.log`. Android APK build and real device/network deployment remain unverified in this environment.
