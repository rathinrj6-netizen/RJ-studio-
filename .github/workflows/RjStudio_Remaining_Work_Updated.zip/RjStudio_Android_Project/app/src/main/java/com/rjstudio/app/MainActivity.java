package com.rjstudio.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.content.ActivityNotFoundException;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.os.Build;
import android.content.pm.PackageManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import org.json.JSONArray;
import android.view.Window;
import android.webkit.WebChromeClient.FileChooserParams;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1201;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(android.graphics.Color.rgb(7, 11, 24));
        w.setNavigationBarColor(android.graphics.Color.rgb(7, 11, 24));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(7, 11, 24));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return true;
                // Keep the JavaScript bridge confined to the bundled, trusted app UI.
                if (url.startsWith("file:///android_asset/")) return false;
                if (url.startsWith("https://")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (ActivityNotFoundException ignored) { /* No browser available. */ }
                    return true;
                }
                // Block cleartext HTTP, javascript:, content:, and unknown schemes.
                return true;
            }
        });
        webView.addJavascriptInterface(new BackgroundBridge(), "RjBackground");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        setContentView(webView);
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private class BackgroundBridge {
        @JavascriptInterface public void start() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1202);
                }
                getSharedPreferences("rj_assistant", MODE_PRIVATE).edit().putBoolean("service_enabled", true).apply();
                Intent i = new Intent(MainActivity.this, BackgroundAssistantService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
            });
        }
        @JavascriptInterface public void stop() {
            runOnUiThread(() -> {
                getSharedPreferences("rj_assistant", MODE_PRIVATE).edit().putBoolean("service_enabled", false).apply();
                stopService(new Intent(MainActivity.this, BackgroundAssistantService.class));
            });
        }
        @JavascriptInterface public boolean isAvailable() { return true; }
        @JavascriptInterface public String getTasks() {
            return getSharedPreferences("rj_assistant", MODE_PRIVATE).getString("tasks_json", "[]");
        }
        @JavascriptInterface public void saveTasks(String json) {
            try {
                JSONArray parsed = new JSONArray(json);
                getSharedPreferences("rj_assistant", MODE_PRIVATE).edit().putString("tasks_json", parsed.toString()).apply();
                boolean enabled = getSharedPreferences("rj_assistant", MODE_PRIVATE).getBoolean("service_enabled", false);
                if (enabled) {
                    Intent refresh = new Intent(MainActivity.this, BackgroundAssistantService.class);
                    refresh.setAction(BackgroundAssistantService.ACTION_REFRESH);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(refresh); else startService(refresh);
                }
            } catch (Exception ignored) { /* Ignore malformed task data. */ }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
