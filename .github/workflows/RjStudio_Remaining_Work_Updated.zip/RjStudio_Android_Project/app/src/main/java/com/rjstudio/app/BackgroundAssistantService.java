package com.rjstudio.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import org.json.JSONArray;

/** Persistent, user-started status service. It tracks queued tasks; it is not an AI executor. */
public class BackgroundAssistantService extends Service {
    public static final String ACTION_REFRESH = "com.rjstudio.app.REFRESH_ASSISTANT_STATUS";
    private static final String CHANNEL = "rj_background_assistant";
    private static final int NOTIFICATION_ID = 4120;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            NotificationChannel channel = new NotificationChannel(CHANNEL, "RJ Studio Background Assistant", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("RJ Studio background task status and progress notifications");
            manager.createNotificationChannel(channel);
        }
    }

    private int pendingCount() {
        SharedPreferences prefs = getSharedPreferences("rj_assistant", MODE_PRIVATE);
        String json = prefs.getString("tasks_json", "[]");
        try {
            JSONArray tasks = new JSONArray(json);
            int pending = 0;
            for (int i = 0; i < tasks.length(); i++) {
                String status = tasks.optJSONObject(i) == null ? "queued" : tasks.optJSONObject(i).optString("status", "queued");
                if (!"done".equals(status) && !"cancelled".equals(status)) pending++;
            }
            return pending;
        } catch (Exception ignored) { return 0; }
    }

    private Notification buildNotification() {
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        int pending = pendingCount();
        String text = pending == 0
            ? "সহকারী চালু আছে; বর্তমানে অপেক্ষমাণ কাজ নেই। AI ইঞ্জিন সংযুক্ত নয়।"
            : "অপেক্ষমাণ/চলমান কাজ: " + pending + "টি। কাজের তালিকা অ্যাপে দেখুন।";
        return builder.setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("RJ Studio Background Assistant")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_REFRESH.equals(intent.getAction())) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.notify(NOTIFICATION_ID, buildNotification());
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
