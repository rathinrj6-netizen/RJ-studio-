'use strict';
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { root, walk, result } = require('./common');
const files = walk(root, p => p.endsWith('.js') && !p.includes('/node_modules/'));
const failed = [];
for (const f of files) {
  const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
  if (r.status !== 0) failed.push({ file: f.replace(root + '/', ''), error: (r.stderr || r.stdout).trim() });
}
const html = path.join(root, 'app/src/main/assets/index.html');
let inlineChecked = 0;
if (fs.existsSync(html)) {
  const content = fs.readFileSync(html, 'utf8');
  const scripts = [...content.matchAll(/<script\b(?![^>]*\bsrc\s*=)[^>]*>([\s\S]*?)<\/script>/gi)];
  for (let i = 0; i < scripts.length; i++) {
    inlineChecked++;
    const temp = path.join(os.tmpdir(), `rj-inline-script-${process.pid}-${i}.js`);
    try {
      fs.writeFileSync(temp, scripts[i][1]);
      const r = spawnSync(process.execPath, ['--check', temp], { encoding: 'utf8' });
      if (r.status !== 0) failed.push({ file: `app/src/main/assets/index.html inline script ${i + 1}`, error: (r.stderr || r.stdout).trim() });
    } finally { try { fs.unlinkSync(temp); } catch {} }
  }
}
console.log(JSON.stringify(result('03 Node & HTML Script Syntax', !failed.length, { checkedNodeFiles: files.length, checkedInlineScripts: inlineChecked, failed }), null, 2));
if (failed.length) process.exitCode = 1;
