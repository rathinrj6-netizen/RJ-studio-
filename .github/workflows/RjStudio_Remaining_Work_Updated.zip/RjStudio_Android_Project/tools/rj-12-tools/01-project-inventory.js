'use strict'; const {fs,root,walk,result}=require('./common');
const files=walk(root); const required=['settings.gradle','build.gradle','app/build.gradle','server/server.js','server/task-server.js','server/agent-worker.js'];
const missing=required.filter(f=>!fs.existsSync(root+'/'+f));
console.log(JSON.stringify(result('01 Project Inventory',!missing.length,{fileCount:files.length,missing}),null,2)); if(missing.length)process.exitCode=1;
