# RJ Studio: ১২টি আলাদা কোডিং টুল / সফটওয়্যার মডিউল

এগুলো একই প্রজেক্টে রাখা ১২টি আলাদা Node.js টুল; এগুলো ১২টি আলাদা কোম্পানির সফটওয়্যার বা অনলাইন সার্ভার নয়। কিছু পরীক্ষা স্বয়ংক্রিয়, আর API key/হোস্টিং/Android SDK-নির্ভর কাজ আলাদা করে চিহ্নিত হয়।

## ১২টি টুল
1. Project Inventory — দরকারি ফাইল আছে কি না
2. Environment Preflight — গোপন মান না দেখিয়ে কোন কনফিগারেশন অনুপস্থিত তা দেখায়
3. Node Syntax — JavaScript syntax check
4. JSON/XML Validator — কনফিগারেশন ফাইল যাচাই
5. Security Config Audit — production token guard ও wildcard CORS-এর সাধারণ পরীক্ষা
6. Task Queue Audit — কাজের তালিকার গঠন যাচাই
7. Gateway API Smoke Tests — বিদ্যমান API smoke test
8. Task API Tests — task API test
9. Android Build Preflight — SDK/Gradle উপস্থিতি পরীক্ষা; APK বানায় না
10. Dependency Metadata Audit — package metadata; অনলাইন vulnerability scan নয়
11. Safe Source Backup — প্রজেক্টের সোর্স কপি করে `reports/source-backup/`-এ রাখে
12. Status Report — সোর্স, workflow, APK artifact এবং অনলাইন ডিপ্লয়মেন্টের অবস্থা রিপোর্ট করে

## চালানো
প্রজেক্টের root-এ:

```sh
node tools/rj-12-tools/run-all.js
node tools/rj-12-tools/11-safe-backup.js
```

## সীমাবদ্ধতা
- `run-all.js`-এর PASS মানে শুধু নির্দিষ্ট লোকাল পরীক্ষা পাস; পূর্ণ অ্যাপ ঠিক আছে বা APK তৈরি হয়েছে এমন প্রমাণ নয়।
- AI চালাতে provider API key, endpoint, model এবং সার্ভার token কনফিগার করতে হবে। API key APK-তে রাখবেন না।
- অনলাইন deploy, ফোনে পরীক্ষা, Play Store প্রকাশ বা আয় চালু হয়েছে বলে এই টুলগুলো দাবি করে না।
- APK তৈরির জন্য Android SDK/Gradle এবং সফল GitHub Actions build দরকার।
