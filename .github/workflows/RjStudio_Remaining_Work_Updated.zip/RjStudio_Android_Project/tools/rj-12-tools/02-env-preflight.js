'use strict'; const {fs,root,result}=require('./common');
const example=fs.existsSync(root+'/server/.env.example'); const required=['AI_BASE_URL','AI_API_KEY','AI_MODEL','RJ_GATEWAY_TOKEN','RJ_TASKS_TOKEN'];
const present=required.filter(k=>Boolean(process.env[k])); const missing=required.filter(k=>!process.env[k]);
console.log(JSON.stringify(result('02 Environment Preflight',example,{envExampleExists:example,requiredVariables:required,configuredVariables:present,notConfigured:missing,secretValuesNeverPrinted:true}),null,2));
