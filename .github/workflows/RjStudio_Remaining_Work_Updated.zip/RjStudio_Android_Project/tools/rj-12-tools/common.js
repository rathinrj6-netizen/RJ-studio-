'use strict';
const fs=require('node:fs'); const path=require('node:path');
const root=path.resolve(__dirname,'../..');
function walk(dir,filter=()=>true,out=[]){ if(!fs.existsSync(dir))return out; for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(['.git','node_modules','build','.gradle','source-backup'].includes(e.name))continue;const p=path.join(dir,e.name);if(e.isDirectory())walk(p,filter,out);else if(filter(p))out.push(p);}return out;}
function result(name,ok,details){return {name,ok:Boolean(ok),details};}
module.exports={fs,path,root,walk,result};
