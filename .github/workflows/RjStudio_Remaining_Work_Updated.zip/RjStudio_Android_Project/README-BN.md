# Rj Studio — Android প্রজেক্ট ও সক্ষমতার অবস্থা

এই রিপোজিটরিতে Rj Studio-এর Android WebView প্রোটোটাইপ, ১৪টি সহকারীর UI এবং GitHub Actions-এ APK বিল্ডের workflow আছে। **এটি প্রস্তুত APK নয়।** এই ZIP থেকে ফোনে ইনস্টলযোগ্য APK পেতে ক্লাউড বিল্ড সফল করতে হবে।


## নতুন: Background Assistant + Task Manager

এই সংস্করণে Android foreground service এবং কাজের তালিকা সংরক্ষণের প্রাথমিক ব্যবস্থা আছে। অ্যাপের **ব্যাকগ্রাউন্ড চালু** বোতাম চাপলে স্থায়ী নোটিফিকেশনসহ সার্ভিস শুরু করার অনুরোধ পাঠায়। কাজের তালিকা Android SharedPreferences-এ সংরক্ষিত হয়; অ্যাপ পুনরায় খুললে তালিকা ফিরে পাওয়ার কথা। সার্ভিস নোটিফিকেশনে অপেক্ষমাণ কাজের সংখ্যা দেখায়।

**সীমাবদ্ধতা:** এই সার্ভিস এখনো AI মডেল চালায় না, কোড স্বয়ংক্রিয়ভাবে বদলায় না, GitHub workflow নিজে চালু করে না এবং APK নিজে কম্পাইল করে না। কাজকে “সম্পন্ন” চিহ্নিত করা বর্তমানে ব্যবহারকারীর হাতে। Android নির্মাতা/ব্যাটারি সেটিংস সার্ভিস বন্ধ করতে পারে। এই build ফোনে পরীক্ষা না করা পর্যন্ত একে যাচাইকৃত/সর্বদা-চলমান বলা যাবে না।

## বাস্তব AI backend যুক্ত করার আগে

- API key APK/JavaScript-এ রাখবে না; backend server-এর secret store-এ রাখতে হবে।
- HTTPS-ভিত্তিক নিজস্ব backend endpoint এবং provider-এর অনুমোদিত authentication দরকার।
- AI-কে ফাইল পরিবর্তন, কমান্ড চালানো বা বিল্ড প্রকাশ করার আগে অনুমতি/সীমা দিতে হবে; কাজের audit log রাখতে হবে।
- বিনামূল্যের provider-ও quota/নীতি বদলাতে পারে; কোনো পেইড API স্বয়ংক্রিয়ভাবে চালু করা হয়নি।

## বর্তমানে যা আছে
- Android অ্যাপের বেসিক কাঠামো ও WebView UI
- ১৪টি সহকারীর ডেমো UI (Ethical Hacking Lab ও Code Security Scanner-সহ)
- নিজের কোডে সাধারণ ঝুঁকির pattern খোঁজার অফলাইন স্ক্যানার (শিক্ষামূলক; পূর্ণাঙ্গ অডিট নয়)
- `Build Rj Studio APK` GitHub Actions workflow
- বিল্ড সফল হলে `RjStudio-debug-apk` নামে artifact আপলোড

## যা এখনো বাস্তবে চালু নয়
- কোনো AI মডেল/API backend সংযুক্ত নেই; সহকারীরা এখনো প্রকৃত AI-উত্তর দেয় না।
- ফোনের অন্য অ্যাপ বা সেটিংস নিয়ন্ত্রণের Android Accessibility Service/অন্যান্য native service তৈরি ও পরীক্ষা করা হয়নি।
- অ্যাপের ভেতর থেকে স্বয়ংক্রিয় APK কম্পাইলার নেই। APK তৈরির কাজ GitHub Actions-এর ক্লাউড runner-এ হয়।
- স্বয়ংক্রিয় আপডেট, crash reporting, release signing ও ডিভাইস-ভিত্তিক QA সম্পূর্ণ নয়।

## ফ্রি ক্লাউড বিল্ড
1. ZIP extract করে `RjStudio_Android_Project` ফোল্ডারের **ভেতরের ফাইলগুলো** GitHub repository-র root-এ আপলোড করুন।
2. GitHub-এ **Actions** খুলে `Build Rj Studio APK` নির্বাচন করুন এবং **Run workflow** চাপুন।
3. রান সফল হলে workflow run-এর **Artifacts** থেকে `RjStudio-debug-apk` নামান।
4. ZIP extract করে `app-debug.apk` ইনস্টল করুন। Android-এ চাইলে শুধু আপনার ইচ্ছায় এই উৎসের APK ইনস্টল করার অনুমতি দিন।

## নিরাপদ ফোন নিয়ন্ত্রণের জন্য প্রয়োজনীয় কাজ
- প্রতিটি নিয়ন্ত্রণের জন্য আলাদা, স্পষ্ট ব্যবহারকারী অনুমতি ও ব্যাখ্যা।
- Accessibility Service প্রয়োজন হলে আলাদা native service, ঘোষিত capabilities, opt-in setup screen এবং জরুরি disable switch।
- Android-এর সুরক্ষা সীমা অতিক্রম, গোপন নজরদারি, অনুমতি ছাড়া বার্তা পাঠানো বা লক/নিরাপত্তা ব্যবস্থা পাশ কাটানো নয়।
- কল, SMS, লোকেশন, ফাইল, মাইক্রোফোন, ক্যামেরা ইত্যাদির জন্য প্রয়োজন অনুযায়ী Android permission ও নীতিমালা মেনে কাজ করতে হবে। সব কাজ সব Android সংস্করণে সম্ভব নয়।

## AI ও নিজে APK তৈরির জন্য পরবর্তী ধাপ
1. অনুমোদিত AI backend/API নিরাপদ server-side configuration-এ যুক্ত করা; API key APK/HTML-এ রাখা যাবে না।
2. AI-কে build log পড়তে দেওয়া, সম্ভাব্য কারণ ব্যাখ্যা করা, প্রস্তাবিত patch দেখানো এবং ব্যবহারকারীর অনুমোদনের পরে পরিবর্তন করা।
3. GitHub Actions-এ build, automated checks, artifact upload এবং ঐচ্ছিক signed release যোগ করা। Signing key নিরাপদ secrets-এ রাখতে হবে; কখনো ZIP বা chat-এ পাঠাবেন না।
4. বাস্তব Android ফোনে install, permission, crash, network এবং accessibility পরীক্ষা করা।

**গুরুত্বপূর্ণ:** কোনো সফটওয়্যারকে “কোনো সমস্যাই থাকবে না” বলে নিশ্চয়তা দেওয়া যায় না। APK তৈরি, ইনস্টল ও বাস্তব ডিভাইসে পরীক্ষা সফল না হওয়া পর্যন্ত অ্যাপকে প্রস্তুত/ত্রুটিমুক্ত বলা যাবে না।

## এই সংস্করণে করা সংশোধন
- Android WebView-এর file chooser callback যোগ করা হয়েছে, যাতে গ্যালারি/ফাইল বাছাইয়ের HTML input Android-এ কাজ করার সুযোগ পায়। বাস্তব ফোনে পরীক্ষা আবশ্যক।
- Android manifest-এ INTERNET permission ঘোষণা করা হয়েছে; এটি নিজে AI backend সংযোগ করে না।
- WebView state save/restore এবং Activity বন্ধের সময় file callback/WebView cleanup যোগ করা হয়েছে।
- GitHub Actions-এ Gradle configuration যাচাই, APK artifact এবং ঐচ্ছিক lint report আপলোডের ধাপ রাখা হয়েছে।

## যে বিষয়গুলো এখনো সমাধান হয়েছে বলে দাবি করা যাচ্ছে না
- এই পরিবেশে Android SDK/Gradle toolchain অনুপস্থিত থাকায় APK compile বা device test করা যায়নি।
- প্রকৃত AI model/backend, server-side API key protection, native Bengali speech recognition, সম্পূর্ণ ফোন নিয়ন্ত্রণ, automatic self-repair, signed release/update channel এবং crash analytics এখনো তৈরি/সংযুক্ত নয়।
- GitHub Actions workflow-ও GitHub-এ চালিয়ে সফল ফলাফল দেখা না পর্যন্ত যাচাইকৃত নয়।


## নতুন নিরাপত্তা ল্যাব
- কোড ডিভাইসেই প্যাটার্ন-ভিত্তিকভাবে পরীক্ষা করা হয়; সার্ভারে পাঠানো হয় না।
- `eval`, সম্ভাব্য `innerHTML` ব্যবহার, HTTP URL, hard-coded secret/password, WebView JavaScript এবং Android cleartext/backup সেটিংসের মতো ইঙ্গিত দেখায়।
- এটি false positive/false negative দিতে পারে এবং নিরাপত্তা নিশ্চিত করে না। শুধু নিজের বা অনুমোদিত কোড পরীক্ষা করুন।


## নতুন: AI Gateway সার্ভার (প্রস্তুত, ডিপ্লয় করা হয়নি)

`server/` ফোল্ডারে dependency-free Node.js AI gateway যোগ করা হয়েছে। `server/README-BN.md`-এ চালানোর নির্দেশনা আছে। এটি `/health`, `/api/chat` ও `/api/agent/plan` endpoint দেয় এবং server-side environment variable থেকে AI provider key পড়ে।

**গুরুত্বপূর্ণ:** সার্ভার কোড যোগ করা মানেই সার্ভার অনলাইনে চালু নয়। Hosting-এ deploy এবং `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL` কনফিগার না করা পর্যন্ত বাস্তব AI উত্তর আসবে না। Android অ্যাপের সেটিংসে deployed HTTPS URL বসাতে হবে। এই সংস্করণ AI-কে কোড প্রস্তাব/পরিকল্পনা করতে দেয়, কিন্তু generated code নিজে চালায় না বা ফাইল বদলায় না। নিরাপদ sandboxed coding executor পরবর্তী আলাদা কাজ।
